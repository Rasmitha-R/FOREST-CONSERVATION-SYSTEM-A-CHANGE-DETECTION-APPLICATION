<?php
session_start();

// Check if user is logged in and is officer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'officer') {
    header("Location: forestlogin.php");
    exit();
}

// Redirect to the new officer app interface
header("Location: officer_app.php");
exit();
?>
<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_ndvi_system";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] != 'officer') {
    header("Location: forestlogin.php");
    exit();
}

// Get logged in officer info
$user_id = $_SESSION['user_id'];
$user_sql = "SELECT * FROM users WHERE user_id = $user_id";
$user_result = $conn->query($user_sql);
$user = $user_result->fetch_assoc();

// Fetch reports assigned to this officer
$sql = "SELECT fr.*, u.full_name as analyzed_by_name, aoa.verification_status, aoa.feedback 
        FROM forest_reports fr 
        JOIN users u ON fr.analyzed_by = u.user_id 
        LEFT JOIN officer_actions oa ON fr.report_id = oa.report_id AND oa.officer_id = $user_id
        LEFT JOIN admin_officer_actions aoa ON oa.action_id = aoa.action_id
        ORDER BY fr.report_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Dashboard - ECOSENSE</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
        }
        
        body {
            background: linear-gradient(to bottom, #d0f0c0, #b0e0a0);
            color: #333;
            min-height: 100vh;
        }
        
        .header {
            background: rgba(75, 130, 111, 1);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }
        
        .logo {
            font-size: 1.8em;
            font-weight: bold;
        }
        
        .logo span {
            color: #b0e0a0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logout-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: #ff5252;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .welcome {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .welcome h1 {
            color: #2e7d32;
            margin-bottom: 10px;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-card i {
            font-size: 2.5em;
            margin-bottom: 15px;
            color: #2e7d32;
        }
        
        .stat-card h3 {
            font-size: 1.8em;
            margin-bottom: 10px;
            color: #2e7d32;
        }
        
        .reports-section {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .section-title {
            color: #2e7d32;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #2e7d32;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn-primary {
            background: #2e7d32;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary:hover {
            background: #1b5e20;
        }
        
        .reports-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .reports-table th, .reports-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .reports-table th {
            background-color: #2e7d32;
            color: white;
        }
        
        .reports-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .status-stable {
            background-color: #4caf50;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-moderately {
            background-color: #ffc107;
            color: black;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-unstable {
            background-color: #ff9800;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-critical {
            background-color: #f44336;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .verification-pending {
            background-color: #2196f3;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .verification-verified {
            background-color: #4caf50;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .verification-rejected {
            background-color: #f44336;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-view {
            background: #2196f3;
            color: white;
        }
        
        .btn-view:hover {
            background: #0b7dda;
        }
        
        .btn-submit {
            background: #4caf50;
            color: white;
        }
        
        .btn-submit:hover {
            background: #3d8b40;
        }
        
        footer {
            text-align: center;
            padding: 20px;
            color: #2e7d32;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .reports-table {
                font-size: 0.8em;
            }
            
            .reports-table th, .reports-table td {
                padding: 10px 5px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">ECOSENSE <span>OFFICER</span></div>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($user['full_name']); ?>!</span>
            <a href="forestlogin.php" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome">
            <h1>Forest Officer Dashboard</h1>
            <p>Manage assigned forest reports and submit field verification data</p>
            <a href="forest_report_analysis.php" class="btn-primary" style="margin-top: 15px;">
                <i class="fas fa-file-alt"></i> Forest Report Analysis
            </a>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <i class="fas fa-tasks"></i>
                <h3>
                    <?php
                    $assigned_sql = "SELECT COUNT(*) as assigned FROM officer_actions WHERE officer_id = $user_id";
                    $assigned_result = $conn->query($assigned_sql);
                    $assigned_row = $assigned_result->fetch_assoc();
                    echo $assigned_row['assigned'];
                    ?>
                </h3>
                <p>Assigned Reports</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-check-circle"></i>
                <h3>
                    <?php
                    $completed_sql = "SELECT COUNT(*) as completed 
                                      FROM officer_actions oa 
                                      JOIN admin_officer_actions aoa ON oa.action_id = aoa.action_id 
                                      WHERE oa.officer_id = $user_id AND aoa.verification_status = 'Verified'";
                    $completed_result = $conn->query($completed_sql);
                    $completed_row = $completed_result->fetch_assoc();
                    echo $completed_row['completed'];
                    ?>
                </h3>
                <p>Completed Tasks</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-clock"></i>
                <h3>
                    <?php
                    $pending_sql = "SELECT COUNT(*) as pending 
                                    FROM officer_actions oa 
                                    JOIN admin_officer_actions aoa ON oa.action_id = aoa.action_id 
                                    WHERE oa.officer_id = $user_id AND aoa.verification_status = 'Pending'";
                    $pending_result = $conn->query($pending_sql);
                    $pending_row = $pending_result->fetch_assoc();
                    echo $pending_row['pending'];
                    ?>
                </h3>
                <p>Pending Review</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>
                    <?php
                    $critical_sql = "SELECT COUNT(*) as critical 
                                     FROM forest_reports fr 
                                     JOIN officer_actions oa ON fr.report_id = oa.report_id 
                                     WHERE oa.officer_id = $user_id AND fr.status = 'Critical'";
                    $critical_result = $conn->query($critical_sql);
                    $critical_row = $critical_result->fetch_assoc();
                    echo $critical_row['critical'];
                    ?>
                </h3>
                <p>Critical Areas</p>
            </div>
        </div>
        
        <div class="reports-section">
            <div class="section-title">
                <h2>Assigned Forest Reports</h2>
                <a href="forest_report_analysis.php" class="btn-primary">
                    <i class="fas fa-plus"></i> Generate New Report
                </a>
            </div>
            
            <?php if ($result->num_rows > 0): ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>Forest Name</th>
                        <th>NDVI %</th>
                        <th>Tree Loss %</th>
                        <th>Status</th>
                        <th>Verification</th>
                        <th>Feedback</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['forest_name']); ?></td>
                        <td><?php echo $row['ndvi_percentage']; ?>%</td>
                        <td><?php echo $row['tree_loss_percentage']; ?>%</td>
                        <td>
                            <span class="status-<?php 
                                echo strtolower(str_replace(' ', '-', $row['status'])); 
                            ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td>
                            <?php if($row['verification_status']): ?>
                                <span class="verification-<?php 
                                    echo strtolower($row['verification_status']); 
                                ?>"><?php echo $row['verification_status']; ?></span>
                            <?php else: ?>
                                <span class="verification-pending">Not Assigned</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['feedback'] ?? 'No feedback'); ?></td>
                        <td><?php echo date('M j, Y', strtotime($row['report_date'])); ?></td>
                        <td class="actions">
                            <button class="btn btn-view">View Details</button>
                            <?php if(!$row['verification_status'] || $row['verification_status'] == 'Pending'): ?>
                                <button class="btn btn-submit">Submit Report</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>No assigned forest reports found.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <footer>
        <p>ECOSENSE - Forest Conservation System &copy; 2025</p>
    </footer>
</body>
</html>