<?php
session_start();

// Simple test to verify app interfaces
if (isset($_SESSION['user_id'])) {
    echo "User is logged in as " . $_SESSION['role'] . ".<br><br>";
    
    // Check if required files exist
    $files = [
        'admin_app.php',
        'officer_app.php',
        'forestlogin.php'
    ];
    
    foreach ($files as $file) {
        if (file_exists($file)) {
            echo "✓ $file exists<br>";
        } else {
            echo "✗ $file is missing<br>";
        }
    }
    
    echo "<br>";
    
    if ($_SESSION['role'] == 'admin') {
        echo "<a href='admin_app.php'>Go to Admin App Interface</a><br>";
        echo "<a href='admin_app.php?page=reports'>Go to Admin Reports Page</a><br>";
        echo "<a href='admin_app.php?page=messages'>Go to Admin Messages Page</a><br>";
    } else {
        echo "<a href='officer_app.php'>Go to Officer App Interface</a><br>";
        echo "<a href='officer_app.php?page=reports'>Go to Officer Reports Page</a><br>";
        echo "<a href='officer_app.php?page=messages'>Go to Officer Messages Page</a><br>";
    }
    
    echo "<br><a href='forestlogin.php?logout=1'>Logout</a>";
} else {
    echo "User is not logged in. Please <a href='forestlogin.php'>login</a> first.";
}
?>