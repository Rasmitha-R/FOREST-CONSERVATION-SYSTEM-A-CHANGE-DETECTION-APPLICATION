# ECOSENSE - Forest Conservation System

## 🌳 Complete Forest Monitoring & Alert System

A comprehensive web-based application for forest conservation with NDVI analysis, report management, and officer-admin messaging.

---

## 🚀 NEW FEATURES IMPLEMENTED

### Admin Interface (`admin_app_new.php`)

#### 1. Dashboard Page
- **Active Officers Display** - Shows officers who logged in within the last 30 minutes with their names, usernames, and locations
- **Statistics Cards** - Total reports, critical reports, and active officers count with floating hover effects
- **Latest Reports** - Shows the 5 most recent forest analysis reports with status badges

#### 2. Forest Report Analysis Page
- **Image Upload with Preview** - Upload old and new forest images with **square containers** (1:1 aspect ratio)
- **Upload Notifications** - Mobile-style notifications appear when images are uploaded
- **Auto Forest Name Generation** - Automatically generates forest names from uploaded images (excludes dates, months, years)
- **NDVI Analysis** - Generates NDVI percentage, change detection, and tree loss percentages
- **Status Classification** - Automatic status: Stable, Moderately Stable, Unstable, or Critical
- **Report Actions**:
  - **Delete** - Permanently removes report from database
  - **Download** - Downloads report as PDF
  - **Send** - Send report to specific officer via dropdown selection
- **Search Functionality** - Search reports by forest name
- **Database Storage** - All reports stored in phpMyAdmin `forest_reports` table

#### 3. Messages Page
- **Instagram-Style Messaging** - Chat interface with:
  - **Sent messages** - Black background (rgba(0, 0, 0, 0.85))
  - **Received messages** - Light pink background (rgba(255, 182, 193, 0.6))
- **Officer Dropdown** - Select officers from dropdown list
- **Message Count Badge** - Shows unread message count on bottom navigation
- **Report Attachments** - Reports can be sent as messages
- **Database Storage** - All messages stored in `messages` table

#### 4. Action Taken Page
- **View Officer Actions** - See all action reports submitted by officers
- **Verification Status** - Shows pending or verified status
- **Issue Tracking** - View if officers reported issues and their details
- **Feedback Display** - Read officer feedback on actions taken

### Officer Interface (`officer_app_new.php`)

#### 1. Dashboard Page
- **Statistics Cards** - Total reports, critical reports, and received reports count
- **Conservation Quotes** - Displays random inspiring environmental quotes with beautiful gradient background

#### 2. Report Page
- **Same Analysis Features** - Upload and analyze forest images like admin
- **Send to Admin** - Send reports to admin via dropdown selection
- **View Own Reports** - See all self-generated reports
- **Delete & Download** - Manage own reports

#### 3. Messages Page
- **Chat with Admin** - Instagram-style messaging with admin
  - **Sent messages** - Black background
  - **Received messages** - Light pink background
- **Admin Dropdown** - Select admin from dropdown to send messages
- **Message Notifications** - Unread count displayed

#### 4. Action Taken Page
- **Submit Actions Form** with:
  - Forest Name input
  - Action Description textarea
  - Issue Radio Buttons (Yes/No) - toggles issue description field
  - Issue Description (conditional)
  - Feedback/Notes textarea
- **My Submitted Actions** - View all previously submitted action reports
- **Verification Status** - See if admin verified the action
- **Mobile-Style Notifications** - Success/error notifications on submission

---

## 🎨 UI/UX Improvements

### Bottom Navigation Bar
- **Bigger Icons** - Navigation icons increased to 1.6rem
- **Active Highlighting** - Light green background (rgba(144, 238, 144, 0.3)) when clicked/active
- **Smooth Transitions** - Animations on all interactions
- **Badge Notifications** - Red badge for unread message counts

### Color Scheme
- **Background** - Light green gradient (#d0f0c0, #b0e0a0)
- **App Bar** - rgba(75,130,111,1)
- **Bottom Bar** - rgba(75,130,111,1)
- **Sent Messages** - Black (rgba(0, 0, 0, 0.85))
- **Received Messages** - Light pink (rgba(255, 182, 193, 0.6))

### Image Display
- **Square Containers** - All forest images displayed in 1:1 aspect ratio
- **Upload Preview** - Images preview before analysis
- **Responsive Grid** - 2-column layout for old/new images

---

## 📊 Database Tables

### Existing Tables
- `users` - User authentication and profiles
- `forest_reports` - Forest analysis reports
- `messages` - Admin-officer messaging

### New Tables Created
- `action_taken` - Officer action reports
  - officer_id, forest_name, action_description
  - has_issue, issue_description, feedback
  - verification_status (pending/verified)
  - submitted_at timestamp

### Updated Columns
- `users.location` - Officer location
- `users.last_login` - Last login timestamp (for active officer tracking)
- `messages.status` - Read/unread status

---

## 🔧 Installation & Setup

### 1. Database Setup
Run the setup file to create new tables:
```
http://localhost/smart_ndvi_system/setup_new_db.php
```

### 2. Login
Access the login page:
```
http://localhost/smart_ndvi_system/forestlogin.php
```

### 3. User Roles
- **Admin** - Full access to reports, officer management, action verification
- **Officer** - Can create reports, submit actions, message admin

---

## 📁 File Structure

```
smart_ndvi_system/
├── admin_app_new.php       # New admin interface with all features
├── officer_app_new.php     # New officer interface with all features
├── forestlogin.php         # Updated login with role-based redirect
├── setup_new_db.php        # Database setup script
├── update_schema.sql       # SQL schema updates
├── uploads/                # Uploaded forest images
└── README.md              # This file
```

---

## ✨ Key Features Summary

✅ **Reports Page** - Square image containers, visible old/new images  
✅ **Delete** - Permanent deletion from database and UI  
✅ **Download** - PDF download functionality  
✅ **Send** - Send reports to officers/admin via dropdown  
✅ **Messages** - Instagram-style (black sent, light pink received)  
✅ **Message Send** - Click send button to actually send messages  
✅ **No Errors** - All functionality works without errors  
✅ **Bottom Bar** - Bigger symbols with active highlighting  
✅ **Notifications** - Mobile-style notifications for all actions  
✅ **Database Storage** - Everything stored in phpMyAdmin  
✅ **Active Officers** - Dashboard shows active officers with location  
✅ **Conservation Quotes** - Officer dashboard displays quotes  
✅ **Action Taken** - Officer submission form with verification  
✅ **Search** - Search reports by forest name  

---

## 🎯 Usage Guide

### For Admin:
1. Login as admin
2. View dashboard with active officers and latest reports
3. Go to Reports page to upload and analyze forest images
4. Delete, download, or send reports to officers
5. Use Messages page to chat with officers
6. Check Action Taken page to review officer actions

### For Officer:
1. Login as officer
2. View dashboard with conservation quotes
3. Create forest analysis reports
4. Submit action taken forms for assigned forests
5. Message admin about critical findings
6. Track verification status of submitted actions

---

## 🔐 Security Features
- Session-based authentication
- Role-based access control
- Prepared SQL statements (prevent injection)
- Input validation on all forms
- Password visibility toggle

---

## 📱 Mobile-Friendly
- Responsive design
- Mobile-style app layout
- Touch-friendly buttons
- Bottom navigation bar
- Swipe-friendly interface

---

## 🌟 Future Enhancements
- Real PDF generation for download
- Image analysis with actual NDVI calculation
- Real-time notifications with WebSocket
- File upload for action taken (photos)
- Email notifications for critical reports

---

## 👨‍💻 Developer Notes
- Built with PHP, MySQL, HTML5, CSS3, JavaScript
- Uses Font Awesome icons
- Google Fonts (Roboto)
- No external frameworks
- Pure vanilla JavaScript

---

## 📞 Support
For issues or questions, check the database connection and ensure XAMPP is running.

---

**Developed for ECOSENSE Forest Conservation Initiative**  
*Protecting forests through technology* 🌲🌍💚
