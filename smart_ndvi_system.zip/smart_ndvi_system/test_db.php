<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_ndvi_system";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if tables exist
$tables = ['users', 'forest_reports', 'officer_actions', 'admin_officer_actions', 'messages'];
echo "<h2>Database Table Check</h2>";

foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "<p style='color: green;'>✓ Table '$table' exists</p>";
        
        // Show column info for the table
        $columns = $conn->query("SHOW COLUMNS FROM $table");
        echo "<ul>";
        while ($column = $columns->fetch_assoc()) {
            echo "<li>{$column['Field']} ({$column['Type']})</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>✗ Table '$table' does not exist</p>";
    }
}

$conn->close();
?>