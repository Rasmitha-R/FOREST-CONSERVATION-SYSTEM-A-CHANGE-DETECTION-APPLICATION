-- Create action_taken table if it doesn't exist
CREATE TABLE IF NOT EXISTS `action_taken` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `officer_id` int(11) NOT NULL,
  `forest_name` varchar(255) NOT NULL,
  `action_description` text NOT NULL,
  `has_issue` enum('yes','no') NOT NULL DEFAULT 'no',
  `issue_description` text,
  `feedback` text,
  `verification_status` enum('pending','verified') NOT NULL DEFAULT 'pending',
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`action_id`),
  KEY `officer_id` (`officer_id`),
  FOREIGN KEY (`officer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update users table to add location field if it doesn't exist
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `location` varchar(255) DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_login` timestamp NULL DEFAULT NULL;

-- Update messages table to add status field if it doesn't exist  
ALTER TABLE `messages` ADD COLUMN IF NOT EXISTS `status` enum('read','unread') NOT NULL DEFAULT 'unread';
