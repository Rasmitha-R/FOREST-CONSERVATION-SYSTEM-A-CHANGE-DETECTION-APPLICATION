<?php
session_start();
$conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: forestlogin.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: forestlogin.php");
    exit();
}

// Handle sending message
if (isset($_POST['send_message'])) {
    $receiver_username = $_POST['receiver_username'];
    $message_text = $_POST['message_text'];
    $report_id = isset($_POST['report_id']) ? intval($_POST['report_id']) : null;
    
    // Get receiver info
    $receiver_sql = "SELECT user_id, full_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($receiver_sql);
    $stmt->bind_param("s", $receiver_username);
    $stmt->execute();
    $receiver_result = $stmt->get_result();
    
    if ($receiver_result->num_rows > 0) {
        $receiver = $receiver_result->fetch_assoc();
        $receiver_id = $receiver['user_id'];
        $receiver_name = $receiver['full_name'];
        $sender_name = $_SESSION['full_name'];
        
        // Insert message
        $message_sql = "INSERT INTO messages (sender_id, receiver_id, sender_name, receiver_name, report_id, message, status) VALUES (?, ?, ?, ?, ?, ?, 'unread')";
        $stmt = $conn->prepare($message_sql);
        $stmt->bind_param("iissis", $user_id, $receiver_id, $sender_name, $receiver_name, $report_id, $message_text);
        
        if ($stmt->execute()) {
            header("Location: admin_app_new.php?page=messages&success=Message sent successfully!");
        } else {
            header("Location: admin_app_new.php?page=messages&error=Error sending message.");
        }
    } else {
        header("Location: admin_app_new.php?page=messages&error=Receiver not found.");
    }
    $stmt->close();
    exit();
}

// Handle report upload and analysis
if (isset($_POST['analyze'])) {
    $old_image = $_FILES['old_image']['name'];
    $new_image = $_FILES['new_image']['name'];
    
    // Generate forest name from image names (remove date, extension, etc.)
    $forest_name = generateForestName($old_image);
    
    // Upload images
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $old_target = $target_dir . basename($old_image);
    $new_target = $target_dir . basename($new_image);
    
    if (move_uploaded_file($_FILES['old_image']['tmp_name'], $old_target) && 
        move_uploaded_file($_FILES['new_image']['tmp_name'], $new_target)) {
        
        // Generate mock analysis data
        $ndvi_percentage = rand(40, 90) . "." . rand(0, 99);
        $change_detection_percentage = rand(5, 40) . "." . rand(0, 99);
        $tree_loss_percentage = rand(1, 30) . "." . rand(0, 99);
        
        // Determine status based on tree loss
        $tree_loss = floatval($tree_loss_percentage);
        if ($tree_loss < 5) {
            $status = "Stable";
        } elseif ($tree_loss < 10) {
            $status = "Moderately Stable";
        } elseif ($tree_loss < 20) {
            $status = "Unstable";
        } else {
            $status = "Critical";
        }
        
        // Save report to database
        $stmt = $conn->prepare("INSERT INTO forest_reports (forest_name, old_image, new_image, ndvi_percentage, change_detection_percentage, tree_loss_percentage, status, analyzed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssddsi", $forest_name, $old_image, $new_image, $ndvi_percentage, $change_detection_percentage, $tree_loss_percentage, $status, $user_id);
        
        if ($stmt->execute()) {
            header("Location: admin_app_new.php?page=reports&success=Report generated and images uploaded successfully!");
        } else {
            header("Location: admin_app_new.php?page=reports&error=Error saving report: " . $conn->error);
        }
        $stmt->close();
        exit();
    } else {
        header("Location: admin_app_new.php?page=reports&error=Error uploading images.");
        exit();
    }
}

// Handle report deletion
if (isset($_GET['delete_report'])) {
    $report_id = intval($_GET['delete_report']);
    
    $delete_sql = "DELETE FROM forest_reports WHERE report_id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $report_id);
    if ($stmt->execute()) {
        header("Location: admin_app_new.php?page=reports&success=Report deleted successfully!");
    } else {
        header("Location: admin_app_new.php?page=reports&error=Error deleting report.");
    }
    $stmt->close();
    exit();
}

// Handle sending report to officer
if (isset($_POST['send_report'])) {
    $report_id = intval($_POST['report_id']);
    $receiver_username = $_POST['receiver_username'];
    $message = $_POST['message'];
    
    // Get receiver info
    $receiver_sql = "SELECT user_id, full_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($receiver_sql);
    $stmt->bind_param("s", $receiver_username);
    $stmt->execute();
    $receiver_result = $stmt->get_result();
    
    if ($receiver_result->num_rows > 0) {
        $receiver = $receiver_result->fetch_assoc();
        $receiver_id = $receiver['user_id'];
        $receiver_name = $receiver['full_name'];
        $sender_name = $_SESSION['full_name'];
        
        // Insert message with report
        $message_sql = "INSERT INTO messages (sender_id, receiver_id, sender_name, receiver_name, report_id, message, status) VALUES (?, ?, ?, ?, ?, ?, 'unread')";
        $stmt = $conn->prepare($message_sql);
        $stmt->bind_param("iissis", $user_id, $receiver_id, $sender_name, $receiver_name, $report_id, $message);
        
        if ($stmt->execute()) {
            header("Location: admin_app_new.php?page=reports&success=Report sent successfully to officer!");
        } else {
            header("Location: admin_app_new.php?page=reports&error=Error sending report.");
        }
    } else {
        header("Location: admin_app_new.php?page=reports&error=Receiver not found.");
    }
    $stmt->close();
    exit();
}

// Function to generate forest name from image name
function generateForestName($image_name) {
    // Remove file extension
    $name = pathinfo($image_name, PATHINFO_FILENAME);
    
    // Remove dates (patterns like 2023-12-25, 25-12-2023, etc.)
    $name = preg_replace('/\d{4}[-_]\d{1,2}[-_]\d{1,2}/', '', $name);
    $name = preg_replace('/\d{1,2}[-_]\d{1,2}[-_]\d{4}/', '', $name);
    
    // Remove timestamps
    $name = preg_replace('/\d{6,}/', '', $name);
    
    // Clean up extra characters
    $name = preg_replace('/[-_]+/', ' ', $name);
    $name = trim($name);
    
    // Capitalize words
    $name = ucwords($name);
    
    // If name is empty, use a default
    if (empty($name)) {
        $name = "Unknown Forest";
    }
    
    return $name;
}

// Get current page
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Count unread messages
$unread_sql = "SELECT COUNT(*) as unread_count FROM messages WHERE receiver_id = ? AND status = 'unread'";
$stmt = $conn->prepare($unread_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_result = $stmt->get_result();
$unread_count = $unread_result->fetch_assoc()['unread_count'];
$stmt->close();

// Get active officers (logged in within last 30 minutes)
$active_officers_sql = "SELECT username, full_name, location, last_login FROM users WHERE role = 'officer' AND last_login >= NOW() - INTERVAL 30 MINUTE";
$active_officers_result = $conn->query($active_officers_sql);

// Count reports
$total_reports_sql = "SELECT COUNT(*) as total FROM forest_reports";
$total_reports = $conn->query($total_reports_sql)->fetch_assoc()['total'];

$critical_reports_sql = "SELECT COUNT(*) as critical FROM forest_reports WHERE status = 'Critical'";
$critical_reports = $conn->query($critical_reports_sql)->fetch_assoc()['critical'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ECOSENSE Admin - Forest Monitoring</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
* {
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
}

body {
    background: linear-gradient(to bottom, #d0f0c0, #b0e0a0);
    color: #333;
    min-height: 100vh;
    padding-bottom: 80px;
}

/* App Bar */
.app-bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(75,130,111,1);
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    z-index: 1000;
}

.app-bar-title {
    font-size: 1.3rem;
    font-weight: 700;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logout-btn {
    background: #ff6b6b;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s;
}

.logout-btn:hover {
    background: #ff5252;
}

/* Bottom Navigation */
.bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(75,130,111,1);
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    z-index: 1000;
}

.nav-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    color: white;
    text-decoration: none;
    padding: 8px;
    transition: all 0.3s;
    cursor: pointer;
    position: relative;
}

.nav-item i {
    font-size: 1.6rem;
    margin-bottom: 4px;
}

.nav-item span {
    font-size: 0.75rem;
}

.nav-item.active {
    background: rgba(144, 238, 144, 0.3);
    border-radius: 12px;
}

.nav-item .badge {
    position: absolute;
    top: 5px;
    right: calc(50% - 25px);
    background: #ff4444;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 0.7rem;
    font-weight: bold;
}

/* Main Content */
.main-content {
    margin-top: 60px;
    padding: 20px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
}

.page-content {
    display: none;
}

.page-content.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Page Header */
.page-header {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.page-header h2 {
    color: rgba(75,130,111,1);
    margin-bottom: 5px;
}

.page-header p {
    color: #666;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s, box-shadow 0.3s;
}

.stat-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.stat-icon {
    font-size: 2.5rem;
    margin-bottom: 10px;
}

.stat-details h3 {
    font-size: 2rem;
    color: rgba(75,130,111,1);
    margin-bottom: 5px;
}

.stat-details p {
    color: #666;
    font-size: 0.9rem;
}

/* Officers List */
.officers-list {
    display: grid;
    gap: 12px;
}

.officer-item {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    padding: 15px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

.officer-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
}

.officer-info {
    flex: 1;
}

.officer-info h4 {
    margin: 0;
    color: #333;
}

.officer-info p {
    margin: 0;
    color: #666;
    font-size: 0.9rem;
}

.officer-location {
    display: flex;
    align-items: center;
    gap: 5px;
    color: #666;
}

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

.status-badge.active {
    background: #4caf50;
    color: white;
}

/* Section Card */
.section-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.section-header {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid rgba(75,130,111,0.3);
}

.section-header h3 {
    color: rgba(75,130,111,1);
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Latest Reports */
.latest-reports {
    display: grid;
    gap: 12px;
}

.report-mini-card {
    background: rgba(240, 240, 240, 0.8);
    border-radius: 10px;
    padding: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.report-mini-info h4 {
    margin: 0 0 5px 0;
    color: #333;
}

.report-mini-info p {
    margin: 0;
    color: #666;
    font-size: 0.85rem;
}

.status-stable { background: #4caf50; color: white; }
.status-moderately-stable { background: #ff9800; color: white; }
.status-unstable { background: #ff5722; color: white; }
.status-critical { background: #f44336; color: white; }

/* Report Analysis Page */
.image-upload-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

.image-container {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    padding: 15px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

.image-container h3 {
    color: rgba(75,130,111,1);
    margin-bottom: 10px;
    text-align: center;
}

.image-preview {
    width: 100%;
    aspect-ratio: 1/1;
    background: #f0f0f0;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 10px;
    overflow: hidden;
    border: 2px dashed #ccc;
}

.image-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.image-preview i {
    font-size: 3rem;
    color: #ccc;
}

.upload-input {
    display: block;
    width: 100%;
    padding: 10px;
    background: rgba(75,130,111,1);
    color: white;
    text-align: center;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 500;
}

.upload-input:hover {
    background: rgba(75,130,111,0.8);
}

.analyze-btn {
    width: 100%;
    padding: 12px;
    background: #4caf50;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    margin-bottom: 30px;
}

.analyze-btn:hover {
    background: #45a049;
}

/* Reports List */
.reports-list {
    display: grid;
    gap: 20px;
}

.report-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.report-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid #f0f0f0;
}

.report-title h3 {
    margin: 0;
    color: rgba(75,130,111,1);
}

.report-date {
    color: #666;
    font-size: 0.9rem;
}

.report-images {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 15px;
}

.report-image-box {
    position: relative;
}

.report-image-box h4 {
    margin: 0 0 8px 0;
    color: #555;
    font-size: 0.95rem;
}

.report-image-box img {
    width: 100%;
    aspect-ratio: 1/1;
    object-fit: cover;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.report-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 10px;
    margin-bottom: 15px;
}

.report-stat {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
}

.report-stat label {
    display: block;
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 5px;
}

.report-stat value {
    display: block;
    font-size: 1.3rem;
    font-weight: bold;
    color: rgba(75,130,111,1);
}

.report-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

.action-btn {
    padding: 10px;
    border: none;
    border-radius: 8px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.delete-btn {
    background: #ff6b6b;
    color: white;
}

.delete-btn:hover {
    background: #ff5252;
}

.download-btn {
    background: #4caf50;
    color: white;
}

.download-btn:hover {
    background: #45a049;
}

.send-btn {
    background: #2196f3;
    color: white;
}

.send-btn:hover {
    background: #1976d2;
}

/* Send Form */
.send-form {
    display: none;
    margin-top: 15px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
}

.send-form.active {
    display: block;
}

.send-form select,
.send-form input,
.send-form textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 0.95rem;
}

.send-form button {
    width: 100%;
    padding: 10px;
    background: #2196f3;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: 500;
    cursor: pointer;
}

.send-form button:hover {
    background: #1976d2;
}

/* Messages Page */
.message-list {
    max-height: 500px;
    overflow-y: auto;
    margin-bottom: 20px;
}

.message-item {
    display: flex;
    gap: 12px;
    margin-bottom: 15px;
    padding: 12px;
    border-radius: 15px;
}

.message-item.sent {
    background: rgba(0, 0, 0, 0.85);
    margin-left: 50px;
    flex-direction: row-reverse;
}

.message-item.sent .message-content {
    text-align: right;
}

.message-item.sent .message-text,
.message-item.sent .message-sender,
.message-item.sent .message-time {
    color: white;
}

.message-item.received {
    background: rgba(255, 182, 193, 0.6);
    margin-right: 50px;
}

.message-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    flex-shrink: 0;
}

.message-content {
    flex: 1;
}

.message-sender {
    font-weight: 600;
    margin-bottom: 5px;
    color: #333;
}

.message-text {
    margin-bottom: 5px;
    color: #333;
}

.message-time {
    font-size: 0.75rem;
    color: #666;
}

.compose-message {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    padding: 15px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.compose-message select,
.compose-message textarea {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
}

.compose-message textarea {
    min-height: 100px;
    resize: vertical;
}

.compose-message button {
    width: 100%;
    padding: 12px;
    background: rgba(75,130,111,1);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 500;
    cursor: pointer;
}

.compose-message button:hover {
    background: rgba(75,130,111,0.8);
}

/* Action Taken Page */
.action-list {
    display: grid;
    gap: 15px;
}

.action-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

.action-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid #f0f0f0;
}

.action-info h4 {
    margin: 0 0 5px 0;
    color: rgba(75,130,111,1);
}

.action-info p {
    margin: 0;
    color: #666;
    font-size: 0.9rem;
}

.action-body {
    margin-bottom: 10px;
}

.action-body label {
    font-weight: 600;
    color: #555;
}

.action-body p {
    margin: 5px 0;
    color: #333;
}

.verification-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

.verification-badge.verified {
    background: #4caf50;
    color: white;
}

.verification-badge.pending {
    background: #ff9800;
    color: white;
}

/* Notifications */
.notification {
    position: fixed;
    top: 80px;
    right: 20px;
    padding: 15px 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    z-index: 2000;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        transform: translateX(400px);
    }
    to {
        transform: translateX(0);
    }
}

.notification.success {
    border-left: 4px solid #4caf50;
}

.notification.error {
    border-left: 4px solid #f44336;
}

.notification.info {
    border-left: 4px solid #2196f3;
}

/* Search Bar */
.search-bar {
    margin-bottom: 20px;
}

.search-bar input {
    width: 100%;
    padding: 12px 40px 12px 15px;
    border: 2px solid rgba(75,130,111,0.3);
    border-radius: 25px;
    font-size: 1rem;
    background: rgba(255, 255, 255, 0.9);
}

.search-bar input:focus {
    outline: none;
    border-color: rgba(75,130,111,1);
}

.no-data {
    text-align: center;
    padding: 40px;
    color: #999;
}

.no-data i {
    font-size: 3rem;
    margin-bottom: 15px;
    display: block;
}
</style>
</head>
<body>
    <!-- App Bar -->
    <div class="app-bar">
        <div class="app-bar-title">
            <i class="fas fa-leaf"></i> ECOSENSE Admin
        </div>
        <div class="user-info">
            <span><?php echo htmlspecialchars($user_full_name); ?></span>
            <a href="?logout=1" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="notification success" id="notification">
            <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error'])): ?>
        <div class="notification error" id="notification">
            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_GET['error']); ?>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Dashboard Page -->
        <div id="dashboardPage" class="page-content <?php echo $page == 'dashboard' ? 'active' : ''; ?>">
            <div class="page-header">
                <h2><i class="fas fa-chart-line"></i> Admin Dashboard</h2>
                <p>Welcome back, <?php echo htmlspecialchars($user_full_name); ?>!</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-file-alt"></i></div>
                    <div class="stat-details">
                        <h3><?php echo $total_reports; ?></h3>
                        <p>Total Reports</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="stat-details">
                        <h3><?php echo $critical_reports; ?></h3>
                        <p>Critical Reports</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-friends"></i></div>
                    <div class="stat-details">
                        <h3><?php echo $active_officers_result->num_rows; ?></h3>
                        <p>Active Officers</p>
                    </div>
                </div>
            </div>
            
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fas fa-users"></i> Active Officers</h3>
                </div>
                <div class="officers-list">
                    <?php 
                    mysqli_data_seek($active_officers_result, 0);
                    if ($active_officers_result->num_rows > 0):
                        while($officer = $active_officers_result->fetch_assoc()):
                    ?>
                    <div class="officer-item">
                        <div class="officer-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="officer-info">
                            <h4><?php echo htmlspecialchars($officer['full_name']); ?></h4>
                            <p>@<?php echo htmlspecialchars($officer['username']); ?></p>
                        </div>
                        <div class="officer-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <span><?php echo htmlspecialchars($officer['location'] ?? 'Unknown'); ?></span>
                        </div>
                        <div class="officer-status">
                            <span class="status-badge active">Active</span>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <div class="no-data">
                        <i class="fas fa-user-slash"></i>
                        <p>No officers currently active</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fas fa-clock"></i> Latest Reports</h3>
                </div>
                <div class="latest-reports">
                    <?php
                    $latest_sql = "SELECT * FROM forest_reports ORDER BY report_date DESC LIMIT 5";
                    $latest_result = $conn->query($latest_sql);
                    
                    if ($latest_result->num_rows > 0):
                        while($report = $latest_result->fetch_assoc()):
                    ?>
                    <div class="report-mini-card">
                        <div class="report-mini-info">
                            <h4><?php echo htmlspecialchars($report['forest_name']); ?></h4>
                            <p><?php echo date('M d, Y', strtotime($report['report_date'])); ?></p>
                        </div>
                        <div class="report-mini-status">
                            <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                <?php echo $report['status']; ?>
                            </span>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <div class="no-data">
                        <i class="fas fa-inbox"></i>
                        <p>No reports yet</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Forest Report Analysis Page -->
        <div id="reportsPage" class="page-content <?php echo $page == 'reports' ? 'active' : ''; ?>">
            <div class="page-header">
                <h2><i class="fas fa-chart-area"></i> Forest Report Analysis</h2>
                <p>Upload images and generate NDVI analysis reports</p>
            </div>
            
            <form method="POST" enctype="multipart/form-data" id="analyzeForm">
                <div class="image-upload-section">
                    <div class="image-container">
                        <h3>Old Image</h3>
                        <div class="image-preview" id="old-preview">
                            <i class="fas fa-image"></i>
                        </div>
                        <label class="upload-input" for="old_image">
                            <i class="fas fa-cloud-upload-alt"></i> Choose Old Image
                        </label>
                        <input type="file" name="old_image" id="old_image" accept="image/*" style="display: none;" required onchange="previewImage(this, 'old')">
                    </div>
                    
                    <div class="image-container">
                        <h3>New Image</h3>
                        <div class="image-preview" id="new-preview">
                            <i class="fas fa-image"></i>
                        </div>
                        <label class="upload-input" for="new_image">
                            <i class="fas fa-cloud-upload-alt"></i> Choose New Image
                        </label>
                        <input type="file" name="new_image" id="new_image" accept="image/*" style="display: none;" required onchange="previewImage(this, 'new')">
                    </div>
                </div>
                
                <button type="submit" name="analyze" class="analyze-btn">
                    <i class="fas fa-flask"></i> Analyze Images
                </button>
            </form>
            
            <div class="search-bar">
                <input type="text" id="searchReports" placeholder="🔍 Search reports by forest name..." onkeyup="filterReports()">
            </div>
            
            <div class="reports-list" id="reportsList">
                <?php
                $reports_sql = "SELECT * FROM forest_reports ORDER BY report_date DESC";
                $reports_result = $conn->query($reports_sql);
                
                if ($reports_result->num_rows > 0):
                    while($report = $reports_result->fetch_assoc()):
                ?>
                <div class="report-card" data-forest-name="<?php echo strtolower($report['forest_name']); ?>">
                    <div class="report-header">
                        <div class="report-title">
                            <h3><?php echo htmlspecialchars($report['forest_name']); ?></h3>
                        </div>
                        <div class="report-date">
                            <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($report['report_date'])); ?>
                        </div>
                    </div>
                    
                    <div class="report-images">
                        <div class="report-image-box">
                            <h4>Old Image</h4>
                            <img src="uploads/<?php echo htmlspecialchars($report['old_image']); ?>" alt="Old Image">
                        </div>
                        <div class="report-image-box">
                            <h4>New Image</h4>
                            <img src="uploads/<?php echo htmlspecialchars($report['new_image']); ?>" alt="New Image">
                        </div>
                    </div>
                    
                    <div class="report-stats">
                        <div class="report-stat">
                            <label>NDVI</label>
                            <value><?php echo $report['ndvi_percentage']; ?>%</value>
                        </div>
                        <div class="report-stat">
                            <label>Change</label>
                            <value><?php echo $report['change_detection_percentage']; ?>%</value>
                        </div>
                        <div class="report-stat">
                            <label>Tree Loss</label>
                            <value><?php echo $report['tree_loss_percentage']; ?>%</value>
                        </div>
                        <div class="report-stat">
                            <label>Status</label>
                            <value>
                                <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                    <?php echo $report['status']; ?>
                                </span>
                            </value>
                        </div>
                    </div>
                    
                    <div class="report-actions">
                        <a href="?delete_report=<?php echo $report['report_id']; ?>&page=reports" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this report?')">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                        <button class="action-btn download-btn" onclick="downloadReport(<?php echo $report['report_id']; ?>)">
                            <i class="fas fa-download"></i> Download
                        </button>
                        <button class="action-btn send-btn" onclick="toggleSendForm(<?php echo $report['report_id']; ?>)">
                            <i class="fas fa-paper-plane"></i> Send
                        </button>
                    </div>
                    
                    <div id="sendForm<?php echo $report['report_id']; ?>" class="send-form">
                        <form method="POST">
                            <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">
                            <select name="receiver_username" required>
                                <option value="">Select Officer</option>
                                <?php
                                $officers_sql = "SELECT username, full_name FROM users WHERE role = 'officer'";
                                $officers_list = $conn->query($officers_sql);
                                while($officer = $officers_list->fetch_assoc()):
                                ?>
                                <option value="<?php echo htmlspecialchars($officer['username']); ?>">
                                    <?php echo htmlspecialchars($officer['full_name'] . " (@" . $officer['username'] . ")"); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                            <textarea name="message" placeholder="Add a message..." required></textarea>
                            <button type="submit" name="send_report">Send Report to Officer</button>
                        </form>
                    </div>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <div class="no-data">
                    <i class="fas fa-file-excel"></i>
                    <p>No reports available. Upload images to generate reports.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Messages Page -->
        <div id="messagesPage" class="page-content <?php echo $page == 'messages' ? 'active' : ''; ?>">
            <div class="page-header">
                <h2><i class="fas fa-comments"></i> Messages</h2>
                <p>Chat with forest officers</p>
            </div>
            
            <div class="message-list">
                <?php
                $messages_sql = "SELECT * FROM messages WHERE sender_id = ? OR receiver_id = ? ORDER BY sent_at DESC LIMIT 50";
                $stmt = $conn->prepare($messages_sql);
                $stmt->bind_param("ii", $user_id, $user_id);
                $stmt->execute();
                $messages_result = $stmt->get_result();
                
                if ($messages_result->num_rows > 0):
                    while($message = $messages_result->fetch_assoc()):
                        $is_sent = ($message['sender_id'] == $user_id);
                ?>
                <div class="message-item <?php echo $is_sent ? 'sent' : 'received'; ?>">
                    <div class="message-avatar">
                        <?php echo strtoupper(substr($is_sent ? $message['receiver_name'] : $message['sender_name'], 0, 1)); ?>
                    </div>
                    <div class="message-content">
                        <div class="message-sender">
                            <?php echo htmlspecialchars($is_sent ? $message['receiver_name'] : $message['sender_name']); ?>
                        </div>
                        <div class="message-text">
                            <?php echo htmlspecialchars($message['message']); ?>
                            <?php if ($message['report_id']): ?>
                                <br><small><i class="fas fa-file-alt"></i> Report ID: <?php echo $message['report_id']; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="message-time">
                            <?php echo date('M d, Y h:i A', strtotime($message['sent_at'])); ?>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No messages yet</p>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="compose-message">
                <form method="POST">
                    <select name="receiver_username" required>
                        <option value="">Select Officer</option>
                        <?php
                        $officers_sql = "SELECT username, full_name FROM users WHERE role = 'officer'";
                        $officers_list = $conn->query($officers_sql);
                        while($officer = $officers_list->fetch_assoc()):
                        ?>
                        <option value="<?php echo htmlspecialchars($officer['username']); ?>">
                            <?php echo htmlspecialchars($officer['full_name'] . " (@" . $officer['username'] . ")"); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                    <textarea name="message_text" placeholder="Type your message..." required></textarea>
                    <button type="submit" name="send_message">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>

        <!-- Action Taken Page -->
        <div id="actionTakenPage" class="page-content <?php echo $page == 'action-taken' ? 'active' : ''; ?>">
            <div class="page-header">
                <h2><i class="fas fa-tasks"></i> Officer Action Reports</h2>
                <p>View action taken by officers on forest reports</p>
            </div>
            
            <div class="action-list">
                <?php
                $actions_sql = "SELECT at.*, u.full_name as officer_name FROM action_taken at JOIN users u ON at.officer_id = u.user_id ORDER BY at.submitted_at DESC";
                $actions_result = $conn->query($actions_sql);
                
                if ($actions_result && $actions_result->num_rows > 0):
                    while($action = $actions_result->fetch_assoc()):
                ?>
                <div class="action-card">
                    <div class="action-header">
                        <div class="action-info">
                            <h4><?php echo htmlspecialchars($action['forest_name']); ?></h4>
                            <p>By: <?php echo htmlspecialchars($action['officer_name']); ?> | <?php echo date('M d, Y h:i A', strtotime($action['submitted_at'])); ?></p>
                        </div>
                        <div class="verification-status">
                            <span class="verification-badge <?php echo $action['verification_status'] == 'verified' ? 'verified' : 'pending'; ?>">
                                <?php echo ucfirst($action['verification_status']); ?>
                            </span>
                        </div>
                    </div>
                    <div class="action-body">
                        <label>Action Taken:</label>
                        <p><?php echo htmlspecialchars($action['action_description']); ?></p>
                        
                        <label>Issue Status:</label>
                        <p><?php echo $action['has_issue'] == 'yes' ? 'Yes' : 'No'; ?></p>
                        
                        <?php if ($action['has_issue'] == 'yes'): ?>
                        <label>Issue Details:</label>
                        <p><?php echo htmlspecialchars($action['issue_description']); ?></p>
                        <?php endif; ?>
                        
                        <label>Feedback:</label>
                        <p><?php echo htmlspecialchars($action['feedback'] ?? 'No feedback provided'); ?></p>
                    </div>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <div class="no-data">
                    <i class="fas fa-clipboard-list"></i>
                    <p>No action reports submitted yet</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="?page=dashboard" class="nav-item <?php echo $page == 'dashboard' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="?page=reports" class="nav-item <?php echo $page == 'reports' ? 'active' : ''; ?>">
            <i class="fas fa-chart-area"></i>
            <span>Reports</span>
        </a>
        <a href="?page=messages" class="nav-item <?php echo $page == 'messages' ? 'active' : ''; ?>">
            <i class="fas fa-comments"></i>
            <span>Messages</span>
            <?php if ($unread_count > 0): ?>
            <span class="badge"><?php echo $unread_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="?page=action-taken" class="nav-item <?php echo $page == 'action-taken' ? 'active' : ''; ?>">
            <i class="fas fa-tasks"></i>
            <span>Actions</span>
        </a>
    </div>

    <script>
        // Auto-hide notifications
        setTimeout(() => {
            const notif = document.getElementById('notification');
            if (notif) {
                notif.style.transition = 'opacity 0.5s';
                notif.style.opacity = '0';
                setTimeout(() => notif.remove(), 500);
            }
        }, 3000);

        // Preview images
        function previewImage(input, type) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById(type + '-preview');
                    preview.innerHTML = '<img src="' + e.target.result + '" alt="' + type + ' Image">';
                };
                reader.readAsDataURL(input.files[0]);
                
                // Show notification
                showNotification('Image uploaded: ' + input.files[0].name, 'info');
            }
        }

        // Show notification
        function showNotification(message, type) {
            const notif = document.createElement('div');
            notif.className = 'notification ' + type;
            notif.textContent = message;
            document.body.appendChild(notif);
            setTimeout(() => {
                notif.style.transition = 'opacity 0.5s';
                notif.style.opacity = '0';
                setTimeout(() => notif.remove(), 500);
            }, 2000);
        }

        // Toggle send form
        function toggleSendForm(reportId) {
            const form = document.getElementById('sendForm' + reportId);
            form.classList.toggle('active');
        }

        // Download report as PDF
        function downloadReport(reportId) {
            showNotification('Downloading report #' + reportId + ' as PDF...', 'info');
            // PDF download would be implemented here
            setTimeout(() => {
                showNotification('Report downloaded successfully!', 'success');
            }, 1000);
        }

        // Filter reports
        function filterReports() {
            const searchValue = document.getElementById('searchReports').value.toLowerCase();
            const reports = document.querySelectorAll('.report-card');
            
            reports.forEach(report => {
                const forestName = report.getAttribute('data-forest-name');
                if (forestName.includes(searchValue)) {
                    report.style.display = 'block';
                } else {
                    report.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
