# ECOSENSE - Forest Conservation System

## Overview
This system allows forest officers and administrators to analyze forest images, generate reports, and manage forest conservation data.

## Features Implemented

### Enhanced Forest Login Page (forestlogin.php)
1. **User Authentication**
   - Full name and username fields for registration
   - Session-based authentication with role management
   - Change password functionality

2. **Report Generation**
   - Upload old and new forest images
   - Analyze button to generate NDVI, change detection, and tree loss percentages
   - Automatic status determination (Stable, Moderately Stable, Unstable, Critical)

3. **Report Management**
   - View all generated reports in a searchable table
   - Delete reports permanently
   - Download reports as PDF (simulated)
   - Send reports to officers via username with message

4. **Mobile-Style Notifications**
   - Success and error notifications with fade animations
   - Responsive design for all device sizes

5. **Search Functionality**
   - Search bar to filter reports by any field

## Database Structure
The system uses the following tables:
- `users` - Stores user information (admin/officer)
- `forest_reports` - Stores generated forest analysis reports
- `messages` - Stores messages between users
- `officer_actions` - Tracks officer activities
- `admin_officer_actions` - Tracks verification actions

## File Structure
- `forestlogin.php` - Main login and report management page
- `admin_dash.php` - Admin dashboard
- `officer_dash.php` - Officer dashboard
- `uploads/` - Directory for storing uploaded forest images
- SQL files for database setup

## Usage Instructions

1. **Login/Registration**
   - Enter full name, username, email, password, and role
   - First-time users are automatically registered
   - Existing users can login with their credentials

2. **Generating Reports**
   - After login, use the report form to upload two forest images
   - Click "Analyze Forest Images" to generate a report
   - The system will calculate NDVI, change detection, and tree loss percentages
   - Reports are automatically assigned a status based on tree loss

3. **Managing Reports**
   - View all reports in the table below the form
   - Use the search bar to find specific reports
   - Delete reports using the delete button
   - Download reports as PDF using the download button
   - Send reports to officers using the send button

4. **Sending Reports**
   - Click the "Send" button on any report
   - Enter the recipient's username and an optional message
   - The report will be sent and stored in the messaging system

## Technical Implementation Details

### Security Features
- Session-based authentication
- Prepared statements to prevent SQL injection
- Input validation and sanitization
- Role-based access control

### UI/UX Features
- Responsive design for all device sizes
- Animated notifications for user feedback
- Color-coded status badges for quick visual assessment
- Intuitive form layouts and action buttons

### Data Management
- Automatic report status determination based on tree loss percentages
- Proper database relationships between users and reports
- Efficient data retrieval with JOIN operations
- Proper error handling and user feedback

## Future Enhancements
- Integration with actual NDVI processing algorithms
- Real PDF generation functionality
- Advanced reporting and visualization features
- Map integration for geolocation data
- Automated alerts for critical forest conditions