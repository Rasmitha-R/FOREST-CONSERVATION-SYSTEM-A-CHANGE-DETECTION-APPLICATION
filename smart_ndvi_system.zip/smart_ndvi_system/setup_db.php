<?php
// Database setup script
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP password

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS smart_ndvi_system";
if ($conn->query($sql) === TRUE) {
    echo "Database 'smart_ndvi_system' created or already exists.<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

// Select the database
$conn->select_db("smart_ndvi_system");

// Create users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('admin','officer') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Users table created or already exists.<br>";
} else {
    echo "Error creating users table: " . $conn->error . "<br>";
}

// Create forest_reports table
$sql = "CREATE TABLE IF NOT EXISTS forest_reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    forest_name VARCHAR(150) NOT NULL,
    old_image VARCHAR(255) NOT NULL,
    new_image VARCHAR(255) NOT NULL,
    ndvi_percentage DECIMAL(5,2) NOT NULL,
    change_detection_percentage DECIMAL(5,2) NOT NULL,
    tree_loss_percentage DECIMAL(5,2) NOT NULL,
    report_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Stable','Moderately Stable','Unstable','Critical') NOT NULL,
    analyzed_by INT NOT NULL,
    FOREIGN KEY (analyzed_by) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE
)";

if ($conn->query($sql) === TRUE) {
    echo "Forest reports table created or already exists.<br>";
} else {
    echo "Error creating forest_reports table: " . $conn->error . "<br>";
}

// Create officer_actions table
$sql = "CREATE TABLE IF NOT EXISTS officer_actions (
    action_id INT AUTO_INCREMENT PRIMARY KEY,
    report_id INT NOT NULL,
    officer_id INT NOT NULL,
    officer_name VARCHAR(100) NOT NULL,
    location VARCHAR(255) NOT NULL,
    action_type VARCHAR(255) NOT NULL,
    completion_date DATE NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (report_id) REFERENCES forest_reports(report_id) ON DELETE CASCADE,
    FOREIGN KEY (officer_id) REFERENCES users(user_id) ON DELETE CASCADE
)";

if ($conn->query($sql) === TRUE) {
    echo "Officer actions table created or already exists.<br>";
} else {
    echo "Error creating officer_actions table: " . $conn->error . "<br>";
}

// Create admin_officer_actions table
$sql = "CREATE TABLE IF NOT EXISTS admin_officer_actions (
    admin_action_id INT AUTO_INCREMENT PRIMARY KEY,
    action_id INT NOT NULL,
    admin_id INT NOT NULL,
    admin_name VARCHAR(100) NOT NULL,
    officer_name VARCHAR(100) NOT NULL,
    report_id INT NOT NULL,
    feedback VARCHAR(255) DEFAULT NULL,
    verification_status ENUM('Verified','Pending','Rejected') DEFAULT 'Pending',
    remarks TEXT DEFAULT NULL,
    reviewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (action_id) REFERENCES officer_actions(action_id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (report_id) REFERENCES forest_reports(report_id) ON DELETE CASCADE
)";

if ($conn->query($sql) === TRUE) {
    echo "Admin officer actions table created or already exists.<br>";
} else {
    echo "Error creating admin_officer_actions table: " . $conn->error . "<br>";
}

// Create messages table
$sql = "CREATE TABLE IF NOT EXISTS messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    sender_name VARCHAR(100) NOT NULL,
    receiver_name VARCHAR(100) NOT NULL,
    report_id INT DEFAULT NULL,
    message TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (report_id) REFERENCES forest_reports(report_id) ON DELETE SET NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Messages table created or already exists.<br>";
} else {
    echo "Error creating messages table: " . $conn->error . "<br>";
}

// Insert sample data if tables are empty
// Check if users table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM users");
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
    // Insert sample users
    $sql = "INSERT INTO users (full_name, username, password, email, role) VALUES 
            ('Ravi Kumar', 'admin_ravi', 'admin123', 'admin_ravi@example.com', 'admin'),
            ('Priya Sharma', 'officer_priya', 'officer123', 'officer_priya@example.com', 'officer'),
            ('Arun Singh', 'officer_arun', 'officer456', 'officer_arun@example.com', 'officer')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Sample users inserted.<br>";
    } else {
        echo "Error inserting sample users: " . $conn->error . "<br>";
    }
}

// Check if forest_reports table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM forest_reports");
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
    // Insert sample forest reports
    $sql = "INSERT INTO forest_reports (forest_name, old_image, new_image, ndvi_percentage, change_detection_percentage, tree_loss_percentage, status, analyzed_by) VALUES 
            ('Nilgiri Forest', 'nilgiri_old.jpg', 'nilgiri_new.jpg', 72.50, 12.30, 5.60, 'Stable', 1),
            ('Western Ghats', 'ghats_old.jpg', 'ghats_new.jpg', 58.20, 23.40, 10.10, 'Moderately Stable', 1),
            ('Sundarbans', 'sundar_old.jpg', 'sundar_new.jpg', 42.80, 38.90, 25.60, 'Critical', 1)";
    
    if ($conn->query($sql) === TRUE) {
        echo "Sample forest reports inserted.<br>";
    } else {
        echo "Error inserting sample forest reports: " . $conn->error . "<br>";
    }
}

$conn->close();
echo "<br>Database setup completed!";
?>