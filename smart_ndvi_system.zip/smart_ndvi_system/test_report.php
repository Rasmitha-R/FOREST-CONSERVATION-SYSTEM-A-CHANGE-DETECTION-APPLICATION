<?php
session_start();

// Simple test to verify report functionality
$conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    echo "User is logged in. Testing report functionality...<br><br>";
    
    // Try to insert a test report
    $stmt = $conn->prepare("INSERT INTO forest_reports (forest_name, old_image, new_image, ndvi_percentage, change_detection_percentage, tree_loss_percentage, status, analyzed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $forest_name = "Test Forest";
    $old_image = "test_old.jpg";
    $new_image = "test_new.jpg";
    $ndvi_percentage = 75.50;
    $change_detection_percentage = 12.25;
    $tree_loss_percentage = 5.75;
    $status = "Stable";
    $analyzed_by = $_SESSION['user_id'];
    
    $stmt->bind_param("ssssddsi", $forest_name, $old_image, $new_image, $ndvi_percentage, $change_detection_percentage, $tree_loss_percentage, $status, $analyzed_by);
    
    if ($stmt->execute()) {
        $report_id = $conn->insert_id;
        echo "Test report inserted successfully with ID: " . $report_id . "<br>";
        
        // Now try to retrieve it
        $result = $conn->query("SELECT * FROM forest_reports WHERE report_id = " . $report_id);
        if ($row = $result->fetch_assoc()) {
            echo "Report retrieved successfully:<br>";
            echo "Forest Name: " . $row['forest_name'] . "<br>";
            echo "NDVI: " . $row['ndvi_percentage'] . "%<br>";
            echo "Status: " . $row['status'] . "<br>";
        }
        
        // Clean up - delete the test report
        $conn->query("DELETE FROM forest_reports WHERE report_id = " . $report_id);
        echo "<br>Test report cleaned up.";
    } else {
        echo "Error inserting test report: " . $conn->error;
    }
    $stmt->close();
} else {
    echo "User is not logged in. Please <a href='forestlogin.php'>login</a> first.";
}

$conn->close();
?>