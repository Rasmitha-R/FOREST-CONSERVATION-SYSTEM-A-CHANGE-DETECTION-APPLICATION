<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Database Setup - ECOSENSE</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: linear-gradient(to bottom, #d0f0c0, #b0e0a0);
        padding: 50px;
        text-align: center;
    }
    .container {
        background: white;
        border-radius: 15px;
        padding: 30px;
        max-width: 600px;
        margin: 0 auto;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    h1 {
        color: rgba(75,130,111,1);
    }
    .success {
        color: #4caf50;
        font-weight: bold;
    }
    .error {
        color: #f44336;
        font-weight: bold;
    }
</style>
</head>
<body>
<div class="container">
    <h1>🌳 ECOSENSE Database Setup</h1>
    <?php
    $conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
    if ($conn->connect_error) {
        echo "<p class='error'>Connection failed: " . $conn->connect_error . "</p>";
        exit();
    }
    
    echo "<p class='success'>✓ Connected to database successfully!</p>";
    
    // Read and execute SQL file
    $sql_file = file_get_contents('update_schema.sql');
    $statements = explode(';', $sql_file);
    
    $success_count = 0;
    $error_count = 0;
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (!empty($statement) && !preg_match('/^--/', $statement)) {
            if ($conn->query($statement)) {
                $success_count++;
            } else {
                $error_count++;
                echo "<p class='error'>Error: " . $conn->error . "</p>";
            }
        }
    }
    
    echo "<p class='success'>✓ Executed $success_count statements successfully!</p>";
    if ($error_count > 0) {
        echo "<p class='error'>⚠ $error_count statements had errors.</p>";
    }
    
    echo "<hr>";
    echo "<h3>Database is ready!</h3>";
    echo "<p><a href='forestlogin.php' style='background: rgba(75,130,111,1); color: white; padding: 15px 30px; border-radius: 8px; text-decoration: none; display: inline-block; margin-top: 20px;'>Go to Login Page</a></p>";
    
    $conn->close();
    ?>
</div>
</body>
</html>
