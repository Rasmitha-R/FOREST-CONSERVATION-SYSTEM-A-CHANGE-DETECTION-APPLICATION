<?php
session_start();

// Simple test to verify forest analysis page functionality
if (isset($_SESSION['user_id'])) {
    echo "User is logged in. Testing forest analysis page...<br><br>";
    
    // Check if required files exist
    $files = [
        'forest_report_analysis.php',
        'forestlogin.php',
        'admin_dash.php',
        'officer_dash.php'
    ];
    
    foreach ($files as $file) {
        if (file_exists($file)) {
            echo "✓ $file exists<br>";
        } else {
            echo "✗ $file is missing<br>";
        }
    }
    
    // Check if uploads directory exists
    if (is_dir('uploads')) {
        echo "✓ Uploads directory exists<br>";
    } else {
        echo "✗ Uploads directory does not exist<br>";
    }
    
    echo "<br><a href='forest_report_analysis.php'>Go to Forest Report Analysis Page</a>";
} else {
    echo "User is not logged in. Please <a href='forestlogin.php'>login</a> first.";
}
?>