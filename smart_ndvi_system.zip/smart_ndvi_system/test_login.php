<?php
session_start();

// Simple test to verify login functionality
if (isset($_SESSION['user_id'])) {
    echo "User is logged in:<br>";
    echo "User ID: " . $_SESSION['user_id'] . "<br>";
    echo "Full Name: " . $_SESSION['full_name'] . "<br>";
    echo "Username: " . $_SESSION['username'] . "<br>";
    echo "Role: " . $_SESSION['role'] . "<br>";
    echo "<a href='forestlogin.php?logout=1'>Logout</a>";
} else {
    echo "User is not logged in.<br>";
    echo "<a href='forestlogin.php'>Go to Login Page</a>";
}
?>