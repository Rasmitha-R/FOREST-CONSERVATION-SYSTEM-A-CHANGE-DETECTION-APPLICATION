<?php
// Database connection test
$conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Database connection successful!";

// Test if uploads directory exists
if (is_dir('uploads')) {
    echo "<br>Uploads directory exists.";
} else {
    echo "<br>Uploads directory does not exist.";
}

// Test session functionality
session_start();
if (!isset($_SESSION['test'])) {
    $_SESSION['test'] = "Session working correctly";
    echo "<br>Session initialized.";
} else {
    echo "<br>Session value: " . $_SESSION['test'];
}
?>
<?php
// Simple database connection test
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_ndvi_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully to the database.";

// Check if users table exists
$sql = "SHOW TABLES LIKE 'users'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<br>Users table exists.";
    
    // Check if forest_reports table exists
    $sql = "SHOW TABLES LIKE 'forest_reports'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<br>Forest reports table exists.";
        
        // Count records in forest_reports
        $sql = "SELECT COUNT(*) as count FROM forest_reports";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        echo "<br>Found " . $row['count'] . " forest reports in the database.";
    } else {
        echo "<br>Forest reports table does not exist.";
    }
} else {
    echo "<br>Users table does not exist.";
}

$conn->close();
?>