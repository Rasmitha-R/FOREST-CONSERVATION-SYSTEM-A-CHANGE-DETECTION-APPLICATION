<?php
// Database connection test
$conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Database connection successful!<br><br>";

// Show tables
$result = $conn->query("SHOW TABLES");
echo "Database Tables:<br>";
while ($row = $result->fetch_array()) {
    echo "- " . $row[0] . "<br>";
}

echo "<br>Forest Reports Table Structure:<br>";
$result = $conn->query("DESCRIBE forest_reports");
echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    foreach ($row as $value) {
        echo "<td>" . $value . "</td>";
    }
    echo "</tr>";
}
echo "</table>";

echo "<br>Users Table Structure:<br>";
$result = $conn->query("DESCRIBE users");
echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    foreach ($row as $value) {
        echo "<td>" . $value . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>