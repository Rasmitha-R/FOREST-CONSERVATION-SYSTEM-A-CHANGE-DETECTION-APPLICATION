<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: forestlogin.php");
    exit();
}

// Redirect to the new admin app interface
header("Location: admin_app.php");
exit();
?>
<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_ndvi_system";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: forestlogin.php");
    exit();
}

// Fetch all forest reports
$sql = "SELECT fr.*, u.full_name as analyzed_by_name FROM forest_reports fr JOIN users u ON fr.analyzed_by = u.user_id ORDER BY fr.report_date DESC";
$result = $conn->query($sql);

// Fetch user info
$user_id = $_SESSION['user_id'];
$user_sql = "SELECT * FROM users WHERE user_id = $user_id";
$user_result = $conn->query($user_sql);
$user = $user_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ECOSENSE</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
        }
        
        body {
            background: linear-gradient(to bottom, #d0f0c0, #b0e0a0);
            color: #333;
            min-height: 100vh;
        }
        
        .header {
            background: rgba(75, 130, 111, 1);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }
        
        .logo {
            font-size: 1.8em;
            font-weight: bold;
        }
        
        .logo span {
            color: #b0e0a0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logout-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: #ff5252;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .welcome {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .welcome h1 {
            color: #2e7d32;
            margin-bottom: 10px;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .stat-card i {
            font-size: 2.5em;
            margin-bottom: 15px;
            color: #2e7d32;
        }
        
        .stat-card h3 {
            font-size: 1.8em;
            margin-bottom: 10px;
            color: #2e7d32;
        }
        
        .reports-section {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .section-title {
            color: #2e7d32;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #2e7d32;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn-primary {
            background: #2e7d32;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary:hover {
            background: #1b5e20;
        }
        
        .reports-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .reports-table th, .reports-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .reports-table th {
            background-color: #2e7d32;
            color: white;
        }
        
        .reports-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .status-stable {
            background-color: #4caf50;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-moderately {
            background-color: #ffc107;
            color: black;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-unstable {
            background-color: #ff9800;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .status-critical {
            background-color: #f44336;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        
        .actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-view {
            background: #2196f3;
            color: white;
        }
        
        .btn-view:hover {
            background: #0b7dda;
        }
        
        .btn-edit {
            background: #ff9800;
            color: white;
        }
        
        .btn-edit:hover {
            background: #e68a00;
        }
        
        footer {
            text-align: center;
            padding: 20px;
            color: #2e7d32;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .reports-table {
                font-size: 0.8em;
            }
            
            .reports-table th, .reports-table td {
                padding: 10px 5px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">ECOSENSE <span>ADMIN</span></div>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($user['full_name']); ?>!</span>
            <a href="forestlogin.php" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome">
            <h1>Forest Conservation Dashboard</h1>
            <p>Monitor and manage forest health reports across different regions</p>
            <a href="forest_report_analysis.php" class="btn-primary" style="margin-top: 15px;">
                <i class="fas fa-file-alt"></i> Forest Report Analysis
            </a>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <i class="fas fa-tree"></i>
                <h3>
                    <?php
                    $count_sql = "SELECT COUNT(*) as total FROM forest_reports";
                    $count_result = $conn->query($count_sql);
                    $count_row = $count_result->fetch_assoc();
                    echo $count_row['total'];
                    ?>
                </h3>
                <p>Total Reports</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>
                    <?php
                    $critical_sql = "SELECT COUNT(*) as critical FROM forest_reports WHERE status = 'Critical'";
                    $critical_result = $conn->query($critical_sql);
                    $critical_row = $critical_result->fetch_assoc();
                    echo $critical_row['critical'];
                    ?>
                </h3>
                <p>Critical Areas</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-chart-line"></i>
                <h3>
                    <?php
                    $avg_sql = "SELECT AVG(ndvi_percentage) as avg_ndvi FROM forest_reports";
                    $avg_result = $conn->query($avg_sql);
                    $avg_row = $avg_result->fetch_assoc();
                    echo round($avg_row['avg_ndvi'], 2);
                    ?>%
                </h3>
                <p>Avg. NDVI</p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-user-shield"></i>
                <h3>
                    <?php
                    $officers_sql = "SELECT COUNT(*) as officers FROM users WHERE role = 'officer'";
                    $officers_result = $conn->query($officers_sql);
                    $officers_row = $officers_result->fetch_assoc();
                    echo $officers_row['officers'];
                    ?>
                </h3>
                <p>Active Officers</p>
            </div>
        </div>
        
        <div class="reports-section">
            <div class="section-title">
                <h2>Latest Forest Reports</h2>
                <a href="forest_report_analysis.php" class="btn-primary">
                    <i class="fas fa-plus"></i> Generate New Report
                </a>
            </div>
            
            <?php if ($result->num_rows > 0): ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>Forest Name</th>
                        <th>NDVI %</th>
                        <th>Tree Loss %</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Analyzed By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['forest_name']); ?></td>
                        <td><?php echo $row['ndvi_percentage']; ?>%</td>
                        <td><?php echo $row['tree_loss_percentage']; ?>%</td>
                        <td>
                            <span class="status-<?php 
                                echo strtolower(str_replace(' ', '-', $row['status'])); 
                            ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($row['report_date'])); ?></td>
                        <td><?php echo htmlspecialchars($row['analyzed_by_name']); ?></td>
                        <td class="actions">
                            <button class="btn btn-view">View</button>
                            <button class="btn btn-edit">Review</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>No forest reports found.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <footer>
        <p>ECOSENSE - Forest Conservation System &copy; 2025</p>
    </footer>
</body>
</html>