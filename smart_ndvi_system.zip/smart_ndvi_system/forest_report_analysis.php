<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: forestlogin.php");
    exit();
}

// Redirect to the appropriate app interface based on user role
if ($_SESSION['role'] == 'admin') {
    header("Location: admin_app.php?page=reports");
} else {
    header("Location: officer_app.php?page=reports");
}
exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forest Report Analysis - ECOSENSE</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
* {
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
}

body {
    background: linear-gradient(135deg, #1a512e 0%, #3a7d5a 50%, #1a512e 100%);
    color: #333;
    min-height: 100vh;
    padding: 20px;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(255, 255, 255, 0.9);
    padding: 20px 30px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
    margin-bottom: 30px;
}

.logo {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo-icon {
    font-size: 2.5rem;
    color: #2e7d32;
}

.logo-text {
    font-size: 2rem;
    font-weight: 700;
    color: #2e7d32;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 20px;
}

.role-badge {
    background: #2e7d32;
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-weight: bold;
}

.logout-btn {
    background: #f44336;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
}

.logout-btn:hover {
    background: #d32f2f;
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.main-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-bottom: 30px;
}

@media (max-width: 992px) {
    .main-content {
        grid-template-columns: 1fr;
    }
}

.card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
}

.card-title {
    color: #2e7d32;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #2e7d32;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.report-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.form-group label {
    font-weight: bold;
    color: #2e7d32;
}

.form-group input[type="file"] {
    padding: 12px;
    border: 2px dashed #2e7d32;
    border-radius: 10px;
    background: rgba(46, 125, 50, 0.05);
    cursor: pointer;
}

.form-group input[type="file"]:hover {
    background: rgba(46, 125, 50, 0.1);
}

.btn-analyze {
    background: linear-gradient(45deg, #4CAF50, #2E7D32);
    color: white;
    border: none;
    padding: 15px;
    border-radius: 10px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn-analyze:hover {
    transform: translateY(-3px);
    box-shadow: 0 7px 15px rgba(0, 0, 0, 0.3);
}

.btn-analyze:active {
    transform: translateY(0);
}

.reports-section {
    grid-column: 1 / -1;
}

.reports-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.search-bar {
    display: flex;
    align-items: center;
    gap: 10px;
}

.search-bar input {
    padding: 12px 15px;
    border-radius: 25px;
    border: 2px solid #2e7d32;
    width: 250px;
    font-size: 1rem;
}

.search-bar button {
    background: #2e7d32;
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.reports-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.reports-table th {
    background: #2e7d32;
    color: white;
    padding: 15px;
    text-align: left;
}

.reports-table td {
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.reports-table tr:last-child td {
    border-bottom: none;
}

.reports-table tr:hover {
    background: rgba(46, 125, 50, 0.05);
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: bold;
    text-align: center;
    display: inline-block;
}

.status-stable { background: #4CAF50; color: white; }
.status-moderately-stable { background: #FFC107; color: black; }
.status-unstable { background: #FF9800; color: white; }
.status-critical { background: #F44336; color: white; }

.report-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn-action {
    padding: 8px 15px;
    border: none;
    border-radius: 6px;
    color: white;
    cursor: pointer;
    font-weight: bold;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 5px;
    transition: all 0.3s ease;
}

.btn-action:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.btn-delete { background: #F44336; }
.btn-download { background: #2196F3; }
.btn-send { background: #9C27B0; }

.send-form {
    background: rgba(156, 39, 176, 0.1);
    padding: 20px;
    border-radius: 10px;
    margin-top: 15px;
    display: none;
}

.send-form.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.send-form input, .send-form textarea {
    width: 100%;
    margin: 10px 0;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 1rem;
}

.send-form textarea {
    min-height: 100px;
    resize: vertical;
}

.send-form .form-buttons {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.send-form button {
    padding: 10px 15px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.btn-send-report { background: #9C27B0; color: white; }
.btn-cancel { background: #757575; color: white; }

.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 20px;
    border-radius: 10px;
    color: white;
    font-weight: bold;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    z-index: 1000;
    animation: fadeInOut 4s forwards;
}

@keyframes fadeInOut {
    0% { opacity: 0; transform: translateX(100%); }
    10% { opacity: 1; transform: translateX(0); }
    90% { opacity: 1; transform: translateX(0); }
    100% { opacity: 0; transform: translateX(100%); }
}

.notification.success { background: #4CAF50; }
.notification.error { background: #F44336; }

.image-preview {
    max-width: 100%;
    max-height: 200px;
    border-radius: 10px;
    margin-top: 10px;
    display: none;
}

.image-preview.active {
    display: block;
}

.footer {
    text-align: center;
    color: rgba(255, 255, 255, 0.8);
    padding: 20px;
    font-weight: bold;
    margin-top: 30px;
}

/* Instagram-style messaging */
.messages-container {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    margin-top: 30px;
}

.messages-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #eee;
}

.message-list {
    max-height: 400px;
    overflow-y: auto;
}

.message-item {
    display: flex;
    gap: 15px;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 15px;
    background: #f5f5f5;
}

.message-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: #2e7d32;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.message-content {
    flex: 1;
}

.message-sender {
    font-weight: bold;
    color: #2e7d32;
    margin-bottom: 5px;
}

.message-text {
    margin-bottom: 10px;
    line-height: 1.5;
}

.message-report {
    background: #e8f5e9;
    padding: 10px;
    border-radius: 8px;
    border-left: 4px solid #4CAF50;
}

.message-time {
    font-size: 0.8rem;
    color: #757575;
}

.compose-message {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 2px solid #eee;
}

.compose-message input, .compose-message textarea {
    flex: 1;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 1rem;
}

.compose-message textarea {
    min-height: 80px;
    resize: vertical;
}

.compose-message button {
    background: #2e7d32;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px 20px;
    cursor: pointer;
    font-weight: bold;
    align-self: flex-start;
}

.compose-message button:hover {
    background: #1b5e20;
}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">
            <div class="logo-icon">🌲</div>
            <div class="logo-text">ECOSENSE</div>
        </div>
        <div class="user-info">
            <div class="role-badge"><?php echo ucfirst($user_role); ?></div>
            <span>Welcome, <?php echo htmlspecialchars($user_full_name); ?>!</span>
            <a href="?logout=1" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <?php if (isset($success_message)): ?>
        <div class="notification success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="notification error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="main-content">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-file-upload"></i> Upload Forest Images</h2>
            <form method="POST" enctype="multipart/form-data" class="report-form">
                <div class="form-group">
                    <label for="old_image">Old Image (Reference)</label>
                    <input type="file" name="old_image" id="old_image" accept="image/*" required onchange="previewImage(this, 'old-preview')">
                    <img id="old-preview" class="image-preview" alt="Old Image Preview">
                </div>
                <div class="form-group">
                    <label for="new_image">New Image (Current)</label>
                    <input type="file" name="new_image" id="new_image" accept="image/*" required onchange="previewImage(this, 'new-preview')">
                    <img id="new-preview" class="image-preview" alt="New Image Preview">
                </div>
                <button type="submit" name="analyze" class="btn-analyze">
                    <i class="fas fa-chart-line"></i> Analyze Forest Images
                </button>
            </form>
        </div>
        
        <div class="card">
            <h2 class="card-title"><i class="fas fa-chart-bar"></i> Analysis Overview</h2>
            <div style="text-align: center; padding: 30px;">
                <div style="font-size: 5rem; margin-bottom: 20px;">📊</div>
                <h3>Forest Analysis Dashboard</h3>
                <p style="margin-top: 15px; color: #666;">
                    Upload forest images to generate detailed analysis reports.<br>
                    Monitor NDVI, change detection, and tree loss percentages.
                </p>
            </div>
        </div>
    </div>
    
    <div class="card reports-section">
        <div class="reports-header">
            <h2 class="card-title"><i class="fas fa-list"></i> Generated Reports</h2>
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Search reports...">
                <button onclick="filterReports()"><i class="fas fa-search"></i></button>
            </div>
        </div>
        
        <?php if (isset($reports_result) && $reports_result->num_rows > 0): ?>
            <div style="overflow-x: auto;">
                <table class="reports-table" id="reportsTable">
                    <thead>
                        <tr>
                            <th>Forest Name</th>
                            <th>NDVI %</th>
                            <th>Change %</th>
                            <th>Loss %</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($report = $reports_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($report['forest_name']); ?></td>
                            <td><?php echo $report['ndvi_percentage']; ?>%</td>
                            <td><?php echo $report['change_detection_percentage']; ?>%</td>
                            <td><?php echo $report['tree_loss_percentage']; ?>%</td>
                            <td>
                                <span class="status-badge status-<?php 
                                    echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                    <?php echo $report['status']; ?>
                                </span>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($report['report_date'])); ?></td>
                            <td class="report-actions">
                                <button class="btn-action btn-delete" 
                                        onclick="confirmDelete(<?php echo $report['report_id']; ?>)">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <button class="btn-action btn-download" 
                                        onclick="downloadReport(<?php echo $report['report_id']; ?>)">
                                    <i class="fas fa-download"></i> Download
                                </button>
                                <button class="btn-action btn-send" 
                                        onclick="showSendForm(<?php echo $report['report_id']; ?>)">
                                    <i class="fas fa-paper-plane"></i> Send
                                </button>
                                
                                <!-- Send Form -->
                                <div class="send-form" id="sendForm<?php echo $report['report_id']; ?>">
                                    <form method="POST">
                                        <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">
                                        <input type="text" name="receiver_username" placeholder="Enter receiver username" required>
                                        <textarea name="message" placeholder="Add a message..."></textarea>
                                        <div class="form-buttons">
                                            <button type="submit" name="send_report" class="btn-send-report">
                                                <i class="fas fa-paper-plane"></i> Send Report
                                            </button>
                                            <button type="button" class="btn-cancel" onclick="hideSendForm(<?php echo $report['report_id']; ?>)">
                                                Cancel
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-file-alt" style="font-size: 3rem; margin-bottom: 20px; color: #ccc;"></i>
                <h3>No Reports Found</h3>
                <p>Generate your first report by uploading forest images above.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Instagram-style messaging section -->
    <div class="messages-container">
        <div class="messages-header">
            <h2 class="card-title"><i class="fas fa-comments"></i> Messages</h2>
            <div style="font-size: 1.2rem; color: #2e7d32;">
                <i class="fas fa-circle" style="color: #4CAF50;"></i> Online
            </div>
        </div>
        
        <div class="message-list">
            <?php
            // Fetch messages for the current user
            $messages_sql = "SELECT * FROM messages WHERE sender_id = ? OR receiver_id = ? ORDER BY sent_at DESC LIMIT 10";
            $stmt = $conn->prepare($messages_sql);
            $stmt->bind_param("ii", $user_id, $user_id);
            $stmt->execute();
            $messages_result = $stmt->get_result();
            
            if ($messages_result->num_rows > 0):
                while($message = $messages_result->fetch_assoc()):
                    $is_sent = $message['sender_id'] == $user_id;
                    $sender_name = $is_sent ? "You" : $message['sender_name'];
                    $avatar_letter = strtoupper(substr($sender_name, 0, 1));
            ?>
            <div class="message-item" style="<?php echo $is_sent ? 'flex-direction: row-reverse; text-align: right;' : ''; ?>">
                <div class="message-avatar"><?php echo $avatar_letter; ?></div>
                <div class="message-content">
                    <div class="message-sender"><?php echo htmlspecialchars($sender_name); ?></div>
                    <div class="message-text"><?php echo htmlspecialchars($message['message']); ?></div>
                    <?php if ($message['report_id']): ?>
                    <div class="message-report">
                        <i class="fas fa-file-alt"></i> Report #<?php echo $message['report_id']; ?> attached
                    </div>
                    <?php endif; ?>
                    <div class="message-time"><?php echo date('M j, Y g:i A', strtotime($message['sent_at'])); ?></div>
                </div>
            </div>
            <?php 
                endwhile;
            else:
            ?>
            <div style="text-align: center; padding: 30px; color: #757575;">
                <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 15px; color: #ccc;"></i>
                <p>No messages yet. Send a report to start a conversation!</p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="compose-message">
            <input type="text" id="receiver_username" placeholder="Username (e.g., officer_priya)">
            <textarea id="message_text" placeholder="Type your message..."></textarea>
            <button onclick="sendMessage()"><i class="fas fa-paper-plane"></i> Send</button>
        </div>
    </div>
    
    <div class="footer">
        <p>ECOSENSE - Forest Conservation System &copy; 2025</p>
    </div>
</div>

<script>
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.classList.add('active');
        }
        reader.readAsDataURL(file);
    }
}

function confirmDelete(reportId) {
    if (confirm("Are you sure you want to permanently delete this report?")) {
        window.location.href = "?delete_report=" + reportId;
    }
}

function downloadReport(reportId) {
    alert("Report #" + reportId + " would be downloaded as PDF in a real implementation.");
}

function showSendForm(reportId) {
    document.getElementById('sendForm' + reportId).classList.add('active');
}

function hideSendForm(reportId) {
    document.getElementById('sendForm' + reportId).classList.remove('active');
}

function filterReports() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const table = document.getElementById('reportsTable');
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        let found = false;
        
        for (let j = 0; j < cells.length - 1; j++) { // Exclude last cell (actions)
            if (cells[j].textContent.toLowerCase().includes(searchTerm)) {
                found = true;
                break;
            }
        }
        
        rows[i].style.display = found ? '' : 'none';
    }
}

function sendMessage() {
    const receiver = document.getElementById('receiver_username').value;
    const message = document.getElementById('message_text').value;
    
    if (receiver && message) {
        // In a real implementation, this would send an AJAX request to the server
        alert(`Message would be sent to ${receiver} in a real implementation.`);
        document.getElementById('receiver_username').value = '';
        document.getElementById('message_text').value = '';
    } else {
        alert('Please enter both username and message.');
    }
}

// Auto-hide notifications after 4 seconds
setTimeout(function() {
    const notifications = document.querySelectorAll('.notification');
    notifications.forEach(function(notification) {
        notification.style.opacity = '0';
        setTimeout(function() {
            notification.remove();
        }, 500);
    });
}, 4000);

// Add event listener for search input
document.getElementById('searchInput').addEventListener('keyup', filterReports);
</script>
</body>
</html>