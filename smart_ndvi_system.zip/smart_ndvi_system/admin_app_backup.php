<?php
session_start();
$conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: forestlogin.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: forestlogin.php");
    exit();
}

// Handle sending message
if (isset($_POST['send_message'])) {
    $receiver_username = $_POST['receiver_username'];
    $message_text = $_POST['message_text'];
    $report_id = isset($_POST['report_id']) ? intval($_POST['report_id']) : null;
    
    // Get receiver info
    $receiver_sql = "SELECT user_id, full_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($receiver_sql);
    $stmt->bind_param("s", $receiver_username);
    $stmt->execute();
    $receiver_result = $stmt->get_result();
    
    if ($receiver_result->num_rows > 0) {
        $receiver = $receiver_result->fetch_assoc();
        $receiver_id = $receiver['user_id'];
        $receiver_name = $receiver['full_name'];
        $sender_name = $_SESSION['full_name'];
        
        // Insert message
        $message_sql = "INSERT INTO messages (sender_id, receiver_id, sender_name, receiver_name, report_id, message, status) VALUES (?, ?, ?, ?, ?, ?, 'unread')";
        $stmt = $conn->prepare($message_sql);
        $stmt->bind_param("iissis", $user_id, $receiver_id, $sender_name, $receiver_name, $report_id, $message_text);
        
        if ($stmt->execute()) {
            header("Location: admin_app.php?page=messages&success=Message sent successfully!");
        } else {
            header("Location: admin_app.php?page=messages&error=Error sending message.");
        }
    } else {
        header("Location: admin_app.php?page=messages&error=Receiver not found.");
    }
    $stmt->close();
    exit();
}

// Handle report upload and analysis
if (isset($_POST['analyze'])) {
    $old_image = $_FILES['old_image']['name'];
    $new_image = $_FILES['new_image']['name'];
    
    // Generate forest name from image names (remove date, extension, etc.)
    $forest_name = generateForestName($old_image);
    
    // Upload images
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $old_target = $target_dir . basename($old_image);
    $new_target = $target_dir . basename($new_image);
    
    if (move_uploaded_file($_FILES['old_image']['tmp_name'], $old_target) && 
        move_uploaded_file($_FILES['new_image']['tmp_name'], $new_target)) {
        
        // Generate mock analysis data
        $ndvi_percentage = rand(40, 90) . "." . rand(0, 99);
        $change_detection_percentage = rand(5, 40) . "." . rand(0, 99);
        $tree_loss_percentage = rand(1, 30) . "." . rand(0, 99);
        
        // Determine status based on tree loss
        $tree_loss = floatval($tree_loss_percentage);
        if ($tree_loss < 5) {
            $status = "Stable";
        } elseif ($tree_loss < 10) {
            $status = "Moderately Stable";
        } elseif ($tree_loss < 20) {
            $status = "Unstable";
        } else {
            $status = "Critical";
        }
        
        // Save report to database
        $stmt = $conn->prepare("INSERT INTO forest_reports (forest_name, old_image, new_image, ndvi_percentage, change_detection_percentage, tree_loss_percentage, status, analyzed_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssddsi", $forest_name, $old_image, $new_image, $ndvi_percentage, $change_detection_percentage, $tree_loss_percentage, $status, $user_id);
        
        if ($stmt->execute()) {
            header("Location: admin_app.php?page=reports&success=Report generated and images uploaded successfully!");
        } else {
            header("Location: admin_app.php?page=reports&error=Error saving report: " . $conn->error);
        }
        $stmt->close();
        exit();
    } else {
        header("Location: admin_app.php?page=reports&error=Error uploading images.");
        exit();
    }
}

// Handle report deletion
if (isset($_GET['delete_report'])) {
    $report_id = intval($_GET['delete_report']);
    // Check if user owns this report or is admin
    $check_sql = "SELECT * FROM forest_reports WHERE report_id = ? AND (analyzed_by = ? OR ? = 'admin')";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("iis", $report_id, $user_id, $_SESSION['role']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $delete_sql = "DELETE FROM forest_reports WHERE report_id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $report_id);
        if ($stmt->execute()) {
            header("Location: admin_app.php?page=reports&success=Report deleted successfully!");
        } else {
            header("Location: admin_app.php?page=reports&error=Error deleting report.");
        }
    } else {
        header("Location: admin_app.php?page=reports&error=You don't have permission to delete this report.");
    }
    $stmt->close();
    exit();
}

// Handle sending report
if (isset($_POST['send_report'])) {
    $report_id = intval($_POST['report_id']);
    $receiver_username = $_POST['receiver_username'];
    $message = $_POST['message'];
    
    // Get receiver info
    $receiver_sql = "SELECT user_id, full_name FROM users WHERE username = ?";
    $stmt = $conn->prepare($receiver_sql);
    $stmt->bind_param("s", $receiver_username);
    $stmt->execute();
    $receiver_result = $stmt->get_result();
    
    if ($receiver_result->num_rows > 0) {
        $receiver = $receiver_result->fetch_assoc();
        $receiver_id = $receiver['user_id'];
        $receiver_name = $receiver['full_name'];
        $sender_name = $_SESSION['full_name'];
        
        // Insert message
        $message_sql = "INSERT INTO messages (sender_id, receiver_id, sender_name, receiver_name, report_id, message) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($message_sql);
        $stmt->bind_param("iissis", $user_id, $receiver_id, $sender_name, $receiver_name, $report_id, $message);
        
        if ($stmt->execute()) {
            header("Location: admin_app.php?page=reports&success=Report sent successfully!");
        } else {
            header("Location: admin_app.php?page=reports&error=Error sending report.");
        }
    } else {
        header("Location: admin_app.php?page=reports&error=Receiver not found.");
    }
    $stmt->close();
    exit();
}

// Function to generate forest name from image name
function generateForestName($image_name) {
    // Remove file extension
    $name = pathinfo($image_name, PATHINFO_FILENAME);
    
    // Remove dates (patterns like 2023-12-25, 25-12-2023, etc.)
    $name = preg_replace('/\d{4}[-_]\d{1,2}[-_]\d{1,2}/', '', $name);
    $name = preg_replace('/\d{1,2}[-_]\d{1,2}[-_]\d{4}/', '', $name);
    
    // Remove timestamps
    $name = preg_replace('/\d{6,}/', '', $name);
    
    // Clean up extra characters
    $name = preg_replace('/[-_]+/', ' ', $name);
    $name = trim($name);
    
    // Capitalize words
    $name = ucwords($name);
    
    // If name is empty, use a default
    if (empty($name)) {
        $name = "Unknown Forest";
    }
    
    return $name;
}

// Get active page from URL parameter, default to dashboard
$active_page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ECOSENSE Admin - Forest Monitoring</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
* {
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
}

body {
    background: linear-gradient(to bottom, #d0f0c0, #b0e0a0);
    color: #333;
    min-height: 100vh;
    padding-bottom: 70px; /* Space for bottom navigation */
}

/* App Bar */
.app-bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(75,130,111,1);
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    z-index: 1000;
}

.app-bar-title {
    font-size: 1.4rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logout-btn {
    background: #ff6b6b;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s;
}

.logout-btn:hover {
    background: #ff5252;
}

.user-menu {
    position: relative;
}

.user-menu-btn {
    background: none;
    border: none;
    color: white;
    font-size: 1.2rem;
    cursor: pointer;
}

.user-dropdown {
    position: absolute;
    top: 100%;
    right: 0;
    background: white;
    color: #333;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 200px;
    display: none;
    z-index: 1001;
}

.user-dropdown.active {
    display: block;
}

.user-dropdown a {
    display: block;
    padding: 12px 15px;
    text-decoration: none;
    color: #333;
    border-bottom: 1px solid #eee;
}

.user-dropdown a:hover {
    background: #f5f5f5;
}

.user-dropdown a:last-child {
    border-bottom: none;
}

/* Main Content */
.main-content {
    margin-top: 70px; /* Space for app bar */
    padding: 20px;
}

.page {
    display: none;
}

.page.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Dashboard Page */
.dashboard-header {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    text-align: center;
    backdrop-filter: blur(10px);
}

.dashboard-header h1 {
    color: #2e7d32;
    margin-bottom: 10px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 15px;
    margin-bottom: 30px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px 15px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.5);
}

.stat-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
}

.stat-icon {
    font-size: 2rem;
    margin-bottom: 10px;
    color: rgba(75,130,111,1);
}

.stat-value {
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 5px;
    color: rgba(75,130,111,1);
}

.stat-label {
    font-size: 0.9rem;
    color: #666;
}

.reports-section {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.5);
}

.section-title {
    color: #2e7d32;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #2e7d32;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.latest-reports {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 15px;
}

.report-card {
    background: rgba(255, 255, 255, 0.6);
    border-radius: 10px;
    padding: 15px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
    border-left: 4px solid #4CAF50;
    transition: all 0.3s ease;
}

.report-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.report-card.critical {
    border-left: 4px solid #f44336;
}

.report-card.moderate {
    border-left: 4px solid #ffc107;
}

.report-card.unstable {
    border-left: 4px solid #ff9800;
}

.report-name {
    font-weight: 700;
    margin-bottom: 10px;
    color: #2e7d32;
}

.report-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 10px;
}

.report-detail {
    font-size: 0.9rem;
}

.report-status {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: bold;
}

.status-stable { background: #4CAF50; color: white; }
.status-moderately-stable { background: #FFC107; color: black; }
.status-unstable { background: #FF9800; color: white; }
.status-critical { background: #F44336; color: white; }

.report-date {
    font-size: 0.8rem;
    color: #757575;
    text-align: right;
}

.officers-section {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-top: 20px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.5);
}

.officer-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.officer-card {
    background: rgba(227, 242, 253, 0.6);
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
    border-left: 4px solid #2196F3;
    transition: all 0.3s ease;
}

.officer-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.officer-name {
    font-weight: 700;
    margin-bottom: 5px;
}

.officer-role {
    font-size: 0.9rem;
    color: #666;
}

/* Forest Report Page */
.report-container {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.5);
}

.report-header {
    text-align: center;
    margin-bottom: 20px;
}

.report-header h2 {
    color: #2e7d32;
    margin-bottom: 10px;
}

.image-upload-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 20px;
}

@media (max-width: 768px) {
    .image-upload-section {
        grid-template-columns: 1fr;
    }
}

.image-container {
    background: rgba(245, 245, 245, 0.8);
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.image-container h3 {
    color: #2e7d32;
    margin-bottom: 10px;
    font-size: 1rem;
}

.image-preview {
    width: 100%;
    height: 150px;
    background: #e0e0e0;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 10px;
    overflow: hidden;
    aspect-ratio: 1/1;
}

.image-preview img {
    max-width: 100%;
    max-height: 100%;
    display: none;
}

.image-preview.placeholder {
    display: flex;
}

.image-preview.active img {
    display: block;
}

.upload-input {
    width: 100%;
    padding: 8px;
    border: 2px dashed #2e7d32;
    border-radius: 8px;
    background: rgba(46, 125, 50, 0.05);
    cursor: pointer;
    text-align: center;
    font-size: 0.9rem;
}

.upload-input:hover {
    background: rgba(46, 125, 50, 0.1);
}

.btn-analyze {
    background: linear-gradient(45deg, #4CAF50, #2E7D32);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    margin: 0 auto 20px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.btn-analyze:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.reports-display {
    background: rgba(255, 255, 255, 0.6);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-top: 20px;
    backdrop-filter: blur(10px);
}

.reports-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.search-bar {
    display: flex;
    align-items: center;
    gap: 10px;
}

.search-bar input {
    padding: 10px 15px;
    border-radius: 20px;
    border: 2px solid rgba(75,130,111,1);
    width: 200px;
    font-size: 0.9rem;
}

.search-bar button {
    background: rgba(75,130,111,1);
    color: white;
    border: none;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.reports-table {
    width: 100%;
    border-collapse: collapse;
}

.reports-table th {
    background: rgba(75,130,111,1);
    color: white;
    padding: 12px;
    text-align: left;
    font-size: 0.9rem;
}

.reports-table td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    font-size: 0.9rem;
}

.reports-table tr:last-child td {
    border-bottom: none;
}

.reports-table tr:hover {
    background: rgba(46, 125, 50, 0.05);
}

.status-badge {
    padding: 4px 8px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: bold;
    text-align: center;
    display: inline-block;
}

.status-stable { background: #4CAF50; color: white; }
.status-moderately-stable { background: #FFC107; color: black; }
.status-unstable { background: #FF9800; color: white; }
.status-critical { background: #F44336; color: white; }

.report-actions {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.btn-action {
    padding: 6px 10px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    font-weight: bold;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 3px;
    transition: all 0.3s ease;
}

.btn-action:hover {
    transform: translateY(-2px);
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
}

.btn-delete { background: #F44336; }
.btn-download { background: #2196F3; }
.btn-send { background: #9C27B0; }

.send-form {
    background: rgba(156, 39, 176, 0.1);
    padding: 15px;
    border-radius: 8px;
    margin-top: 10px;
    display: none;
}

.send-form.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

.send-form select, .send-form textarea {
    width: 100%;
    margin: 8px 0;
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #ddd;
    font-size: 0.9rem;
}

.send-form textarea {
    min-height: 80px;
    resize: vertical;
}

.send-form .form-buttons {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.send-form button {
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    font-size: 0.9rem;
}

.btn-send-report { background: #9C27B0; color: white; }
.btn-cancel { background: #757575; color: white; }

/* Messages Page */
.messages-container {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.5);
}

.messages-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #eee;
}

.message-list {
    max-height: 400px;
    overflow-y: auto;
    margin-bottom: 20px;
}

.message-item {
    display: flex;
    gap: 15px;
    padding: 15px;
    border-radius: 15px;
    margin-bottom: 15px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.message-item.sent {
    background: rgba(0, 0, 0, 0.8);
    margin-left: 50px;
    flex-direction: row-reverse;
}

.message-item.sent .message-content {
    text-align: right;
}

.message-item.sent .message-sender,
.message-item.sent .message-text {
    color: white;
}

.message-item.received {
    background: rgba(255, 182, 193, 0.6);
    margin-right: 50px;
}

.message-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: rgba(75,130,111,1);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.message-content {
    flex: 1;
}

.message-sender {
    font-weight: bold;
    color: rgba(75,130,111,1);
    margin-bottom: 5px;
}

.message-text {
    margin-bottom: 10px;
    line-height: 1.5;
}

.message-report {
    background: rgba(232, 245, 233, 0.8);
    padding: 10px;
    border-radius: 8px;
    border-left: 4px solid #4CAF50;
}

.message-time {
    font-size: 0.8rem;
    color: #757575;
}

.compose-message {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding-top: 20px;
    border-top: 2px solid #eee;
}

.compose-message select, .compose-message textarea {
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 1rem;
}

.compose-message textarea {
    min-height: 100px;
    resize: vertical;
}

.compose-message button {
    background: rgba(75,130,111,1);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px 20px;
    cursor: pointer;
    font-weight: bold;
    align-self: flex-start;
    transition: all 0.3s ease;
}

.compose-message button:hover {
    background: rgba(59, 102, 87, 1);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* Bottom Navigation */
.bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(75,130,111,1);
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    z-index: 1000;
}

.nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.8rem;
    transition: all 0.3s ease;
}

.nav-item.active {
    color: white;
}

.nav-item i {
    font-size: 1.5rem;
}

.nav-item.active {
    background: rgba(144, 238, 144, 0.3);
    border-radius: 10px;
    padding: 5px 10px;
}

.nav-item .badge {
    position: absolute;
    top: 5px;
    right: 15px;
    background: #f44336;
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    font-weight: bold;
}

/* Notifications */
.notification {
    position: fixed;
    top: 80px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 10px;
    color: white;
    font-weight: bold;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    z-index: 1000;
    animation: fadeInOut 4s forwards;
}

@keyframes fadeInOut {
    0% { opacity: 0; transform: translateX(100%); }
    10% { opacity: 1; transform: translateX(0); }
    90% { opacity: 1; transform: translateX(0); }
    100% { opacity: 0; transform: translateX(100%); }
}

.notification.success { background: #4CAF50; }
.notification.error { background: #F44336; }
.notification.info { background: #2196F3; }

/* Responsive */
@media (max-width: 768px) {
    .app-bar-title {
        font-size: 1.2rem;
    }
    
    .stat-value {
        font-size: 1.5rem;
    }
    
    .officer-list {
        grid-template-columns: 1fr;
    }
    
    .latest-reports {
        grid-template-columns: 1fr;
    }
    
    .search-bar input {
        width: 150px;
    }
}
</style>
</head>
<body>
    <!-- App Bar -->
    <div class="app-bar">
        <div class="app-bar-title">
            <i class="fas fa-tree"></i>
            <span>ECOSENSE ADMIN</span>
        </div>
        <div class="user-info">
            <span><?php echo htmlspecialchars($user_full_name); ?></span>
            <a href="?logout=1" class="logout-btn">Logout</a>
        </div>
    </div>

    <!-- Notifications -->
    <?php if (isset($_GET['success'])): ?>
        <div class="notification success"><?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error'])): ?>
        <div class="notification error"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Dashboard Page -->
        <div class="page <?php echo $active_page == 'dashboard' ? 'active' : ''; ?>" id="dashboard-page">
            <div class="dashboard-header">
                <h1>Forest Monitoring Dashboard</h1>
                <p>Welcome back, <?php echo htmlspecialchars($user_full_name); ?>!</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value">
                        <?php
                        $count_sql = "SELECT COUNT(*) as total FROM forest_reports";
                        $count_result = $conn->query($count_sql);
                        $count_row = $count_result->fetch_assoc();
                        echo $count_row['total'];
                        ?>
                    </div>
                    <div class="stat-label">Total Reports</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🔥</div>
                    <div class="stat-value">
                        <?php
                        $critical_sql = "SELECT COUNT(*) as critical FROM forest_reports WHERE status = 'Critical'";
                        $critical_result = $conn->query($critical_sql);
                        $critical_row = $critical_result->fetch_assoc();
                        echo $critical_row['critical'];
                        ?>
                    </div>
                    <div class="stat-label">Critical Areas</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🌱</div>
                    <div class="stat-value">
                        <?php
                        $stable_sql = "SELECT COUNT(*) as stable FROM forest_reports WHERE status = 'Stable'";
                        $stable_result = $conn->query($stable_sql);
                        $stable_row = $stable_result->fetch_assoc();
                        echo $stable_row['stable'];
                        ?>
                    </div>
                    <div class="stat-label">Stable Areas</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⚠️</div>
                    <div class="stat-value">
                        <?php
                        $moderate_sql = "SELECT COUNT(*) as moderate FROM forest_reports WHERE status = 'Moderately Stable'";
                        $moderate_result = $conn->query($moderate_sql);
                        $moderate_row = $moderate_result->fetch_assoc();
                        echo $moderate_row['moderate'];
                        ?>
                    </div>
                    <div class="stat-label">Moderate Areas</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🌊</div>
                    <div class="stat-value">
                        <?php
                        $unstable_sql = "SELECT COUNT(*) as unstable FROM forest_reports WHERE status = 'Unstable'";
                        $unstable_result = $conn->query($unstable_sql);
                        $unstable_row = $unstable_result->fetch_assoc();
                        echo $unstable_row['unstable'];
                        ?>
                    </div>
                    <div class="stat-label">Unstable Areas</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value">
                        <?php
                        $officers_sql = "SELECT COUNT(*) as officers FROM users WHERE role = 'officer'";
                        $officers_result = $conn->query($officers_sql);
                        $officers_row = $officers_result->fetch_assoc();
                        echo $officers_row['officers'];
                        ?>
                    </div>
                    <div class="stat-label">Active Officers</div>
                </div>
            </div>
            
            <div class="reports-section">
                <div class="section-title">
                    <h2>Latest Analyzed Reports</h2>
                </div>
                
                <div class="latest-reports">
                    <?php
                    $latest_reports_sql = "SELECT fr.*, u.full_name as analyzed_by_name FROM forest_reports fr JOIN users u ON fr.analyzed_by = u.user_id ORDER BY fr.report_date DESC LIMIT 6";
                    $latest_reports_result = $conn->query($latest_reports_sql);
                    if ($latest_reports_result->num_rows > 0):
                        while($report = $latest_reports_result->fetch_assoc()):
                    ?>
                    <div class="report-card <?php echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                        <div class="report-name"><?php echo htmlspecialchars($report['forest_name']); ?></div>
                        <div class="report-details">
                            <div class="report-detail">
                                <strong>NDVI:</strong> <?php echo $report['ndvi_percentage']; ?>%
                            </div>
                            <div class="report-detail">
                                <strong>Loss:</strong> <?php echo $report['tree_loss_percentage']; ?>%
                            </div>
                            <div class="report-detail">
                                <strong>Change:</strong> <?php echo $report['change_detection_percentage']; ?>%
                            </div>
                            <div class="report-detail">
                                <span class="report-status status-<?php 
                                    echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                    <?php echo $report['status']; ?>
                                </span>
                            </div>
                        </div>
                        <div class="report-date"><?php echo date('M j, Y', strtotime($report['report_date'])); ?></div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <p>No reports found.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="officers-section">
                <div class="section-title">
                    <h2>Active Officers</h2>
                </div>
                
                <div class="officer-list">
                    <?php
                    $officers_list_sql = "SELECT * FROM users WHERE role = 'officer'";
                    $officers_list_result = $conn->query($officers_list_sql);
                    if ($officers_list_result->num_rows > 0):
                        while($officer = $officers_list_result->fetch_assoc()):
                    ?>
                    <div class="officer-card">
                        <div class="officer-name"><?php echo htmlspecialchars($officer['full_name']); ?></div>
                        <div class="officer-role">@<?php echo htmlspecialchars($officer['username']); ?></div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <p>No officers found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Forest Report Page -->
        <div class="page <?php echo $active_page == 'reports' ? 'active' : ''; ?>" id="reports-page">
            <div class="report-container">
                <div class="report-header">
                    <h2>Forest Image Analysis</h2>
                    <p>Upload old and new forest images to generate analysis reports</p>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="image-upload-section">
                        <div class="image-container">
                            <h3>Old Image</h3>
                            <div class="image-preview placeholder" id="old-preview">
                                <i class="fas fa-image" style="font-size: 2rem; color: #ccc;"></i>
                            </div>
                            <div class="image-preview active" id="old-image-preview" style="display: none;">
                                <img id="old-image" src="" alt="Old Image">
                            </div>
                            <label class="upload-input" for="old_image">
                                <i class="fas fa-cloud-upload-alt"></i> Choose
                            </label>
                            <input type="file" name="old_image" id="old_image" accept="image/*" style="display: none;" onchange="previewImage(this, 'old')">
                        </div>
                        
                        <div class="image-container">
                            <h3>New Image</h3>
                            <div class="image-preview placeholder" id="new-preview">
                                <i class="fas fa-image" style="font-size: 2rem; color: #ccc;"></i>
                            </div>
                            <div class="image-preview active" id="new-image-preview" style="display: none;">
                                <img id="new-image" src="" alt="New Image">
                            </div>
                            <label class="upload-input" for="new_image">
                                <i class="fas fa-cloud-upload-alt"></i> Choose
                            </label>
                            <input type="file" name="new_image" id="new_image" accept="image/*" style="display: none;" onchange="previewImage(this, 'new')">
                        </div>
                    </div>
                    
                    <button type="submit" name="analyze" class="btn-analyze">
                        <i class="fas fa-chart-line"></i> Analyze
                    </button>
                </form>
                
                <div class="reports-display">
                    <div class="reports-header">
                        <h2>Generated Reports</h2>
                        <div class="search-bar">
                            <input type="text" id="searchInput" placeholder="Search reports...">
                            <button onclick="filterReports()"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                    
                    <?php
                    $reports_sql = "SELECT fr.*, u.full_name as analyzed_by_name FROM forest_reports fr JOIN users u ON fr.analyzed_by = u.user_id ORDER BY fr.report_date DESC";
                    $reports_result = $conn->query($reports_sql);
                    
                    if ($reports_result->num_rows > 0):
                    ?>
                    <div style="overflow-x: auto;">
                        <table class="reports-table" id="reportsTable">
                            <thead>
                                <tr>
                                    <th>Forest Name</th>
                                    <th>NDVI %</th>
                                    <th>Change %</th>
                                    <th>Loss %</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($report = $reports_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($report['forest_name']); ?></td>
                                    <td><?php echo $report['ndvi_percentage']; ?>%</td>
                                    <td><?php echo $report['change_detection_percentage']; ?>%</td>
                                    <td><?php echo $report['tree_loss_percentage']; ?>%</td>
                                    <td>
                                        <span class="status-badge status-<?php 
                                            echo strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                            <?php echo $report['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($report['report_date'])); ?></td>
                                    <td class="report-actions">
                                        <button class="btn-action btn-delete" 
                                                onclick="confirmDelete(<?php echo $report['report_id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="btn-action btn-download" 
                                                onclick="downloadReport(<?php echo $report['report_id']; ?>)">
                                            <i class="fas fa-download"></i>
                                        </button>
                                        <button class="btn-action btn-send" 
                                                onclick="showSendForm(<?php echo $report['report_id']; ?>)">
                                            <i class="fas fa-paper-plane"></i>
                                        </button>
                                        
                                        <!-- Send Form -->
                                        <div class="send-form" id="sendForm<?php echo $report['report_id']; ?>">
                                            <form method="POST">
                                                <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">
                                                <select name="receiver_username" required>
                                                    <option value="">Select Officer</option>
                                                    <?php
                                                    $officers_sql = "SELECT username, full_name FROM users WHERE role = 'officer'";
                                                    $officers_result = $conn->query($officers_sql);
                                                    while($officer = $officers_result->fetch_assoc()):
                                                    ?>
                                                    <option value="<?php echo htmlspecialchars($officer['username']); ?>">
                                                        <?php echo htmlspecialchars($officer['full_name'] . " (@" . $officer['username'] . ")"); ?>
                                                    </option>
                                                    <?php endwhile; ?>
                                                </select>
                                                <textarea name="message" placeholder="Add a message..."></textarea>
                                                <div class="form-buttons">
                                                    <button type="submit" name="send_report" class="btn-send-report">
                                                        <i class="fas fa-paper-plane"></i> Send
                                                    </button>
                                                    <button type="button" class="btn-cancel" onclick="hideSendForm(<?php echo $report['report_id']; ?>)">
                                                        Cancel
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: #666;">
                        <i class="fas fa-file-alt" style="font-size: 3rem; margin-bottom: 20px; color: #ccc;"></i>
                        <h3>No Reports Found</h3>
                        <p>Generate your first report by uploading forest images above.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Messages Page -->
        <div class="page <?php echo $active_page == 'messages' ? 'active' : ''; ?>" id="messages-page">
            <div class="messages-container">
                <div class="messages-header">
                    <h2><i class="fas fa-comments"></i> Messages</h2>
                    <div style="font-size: 1.2rem; color: rgba(75,130,111,1);">
                        <i class="fas fa-circle" style="color: #4CAF50;"></i> Online
                    </div>
                </div>
                
                <div class="message-list" id="messageList">
                    <?php
                    // Fetch messages for the current user
                    $messages_sql = "SELECT * FROM messages WHERE receiver_id = ? ORDER BY sent_at DESC";
                    $stmt = $conn->prepare($messages_sql);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $messages_result = $stmt->get_result();
                    
                    if ($messages_result->num_rows > 0):
                        while($message = $messages_result->fetch_assoc()):
                            $sender_sql = "SELECT full_name, username FROM users WHERE user_id = ?";
                            $sender_stmt = $conn->prepare($sender_sql);
                            $sender_stmt->bind_param("i", $message['sender_id']);
                            $sender_stmt->execute();
                            $sender_result = $sender_stmt->get_result();
                            $sender = $sender_result->fetch_assoc();
                            
                            $sender_name = $sender['full_name'];
                            $sender_username = $sender['username'];
                            $avatar_letter = strtoupper(substr($sender_name, 0, 1));
                    ?>
                    <div class="message-item">
                        <div class="message-avatar"><?php echo $avatar_letter; ?></div>
                        <div class="message-content">
                            <div class="message-sender"><?php echo htmlspecialchars($sender_name); ?> (@<?php echo htmlspecialchars($sender_username); ?>)</div>
                            <div class="message-text"><?php echo htmlspecialchars($message['message']); ?></div>
                            <?php if ($message['report_id']): ?>
                            <div class="message-report">
                                <i class="fas fa-file-alt"></i> Report #<?php echo $message['report_id']; ?> attached
                            </div>
                            <?php endif; ?>
                            <div class="message-time"><?php echo date('M j, Y g:i A', strtotime($message['sent_at'])); ?></div>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <div style="text-align: center; padding: 30px; color: #757575;">
                        <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 15px; color: #ccc;"></i>
                        <p>No messages yet. Send a report to start a conversation!</p>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="compose-message">
                    <form method="POST">
                        <select name="receiver_username" id="receiver_username" required>
                            <option value="">Select Officer</option>
                            <?php
                            $officers_sql = "SELECT username, full_name FROM users WHERE role = 'officer'";
                            $officers_result = $conn->query($officers_sql);
                            while($officer = $officers_result->fetch_assoc()):
                            ?>
                            <option value="<?php echo htmlspecialchars($officer['username']); ?>">
                                <?php echo htmlspecialchars($officer['full_name'] . " (@" . $officer['username'] . ")"); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        <textarea name="message_text" id="message_text" placeholder="Type your message..." required></textarea>
                        <button type="submit" name="send_message"><i class="fas fa-paper-plane"></i> Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="?page=dashboard" class="nav-item <?php echo $active_page == 'dashboard' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="?page=reports" class="nav-item <?php echo $active_page == 'reports' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i>
            <span>Reports</span>
        </a>
        <a href="?page=messages" class="nav-item <?php echo $active_page == 'messages' ? 'active' : ''; ?>">
            <i class="fas fa-comments"></i>
            <span>Messages</span>
            <?php
            // Check for unread messages
            $unread_sql = "SELECT COUNT(*) as unread FROM messages WHERE receiver_id = ? AND status = 'unread'";
            $stmt = $conn->prepare($unread_sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $unread_result = $stmt->get_result();
            $unread_row = $unread_result->fetch_assoc();
            $unread_count = $unread_row['unread'];
            
            if ($unread_count > 0):
            ?>
            <span class="badge"><?php echo $unread_count; ?></span>
            <?php endif; ?>
        </a>
    </div>

    <script>
        // Toggle user menu
        function toggleUserMenu() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }
        
        // Close user menu when clicking outside
        document.addEventListener('click', function(e) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            if (!userMenu.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
        
        // Image preview
        function previewImage(input, type) {
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById(type + '-image').src = e.target.result;
                    document.getElementById(type + '-preview').style.display = 'block';
                    document.getElementById(type + '-image-preview').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
        
        // Confirm delete
        function confirmDelete(reportId) {
            if (confirm('Are you sure you want to delete this report?')) {
                window.location.href = '?page=reports&delete_report=' + reportId;
            }
        }
        
        // Download report
        function downloadReport(reportId) {
            alert('Report #' + reportId + ' would be downloaded as PDF in a real implementation.');
        }
        
        // Show send form
        function showSendForm(reportId) {
            document.getElementById('sendForm' + reportId).classList.add('active');
        }
        
        // Hide send form
        function hideSendForm(reportId) {
            document.getElementById('sendForm' + reportId).classList.remove('active');
        }
        
        // Show notification on image upload
        function showUploadNotification(fileName) {
            const notification = document.createElement('div');
            notification.className = 'notification info';
            notification.textContent = 'Uploading ' + fileName + '...';
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 2000);
        }
        
        // Filter reports
        function filterReports() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const table = document.getElementById('reportsTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < cells.length - 1; j++) { // Exclude last cell (actions)
                    if (cells[j].textContent.toLowerCase().includes(searchTerm)) {
                        found = true;
                        break;
                    }
                }
                
                rows[i].style.display = found ? '' : 'none';
            }
        }
        
        // Auto-hide notifications after 4 seconds
        setTimeout(function() {
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(function(notification) {
                notification.style.opacity = '0';
                setTimeout(function() {
                    notification.remove();
                }, 500);
            });
        }, 4000);
        
        // Add event listener for search input
        document.getElementById('searchInput').addEventListener('keyup', filterReports);
    </script>
</body>
</html>