<?php
// Simple PDF Generator for Forest Reports
function generateReportPDF($report_id, $conn) {
    $sql = "SELECT * FROM forest_reports WHERE report_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $report = $stmt->get_result()->fetch_assoc();
    
    if (!$report) {
        die("Report not found");
    }
    
    // Set headers for PDF download
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="Forest_Report_' . $report_id . '.pdf"');
    
    // Create PDF content (simple text-based PDF)
    $pdf_content = "%PDF-1.4\n";
    $pdf_content .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $pdf_content .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $pdf_content .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources 4 0 R /MediaBox [0 0 612 792] /Contents 5 0 R >>\nendobj\n";
    $pdf_content .= "4 0 obj\n<< /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >>\nendobj\n";
    
    $text = "BT\n";
    $text .= "/F1 20 Tf\n";
    $text .= "50 750 Td\n";
    $text .= "(ECOSENSE FOREST REPORT) Tj\n";
    $text .= "0 -30 Td\n";
    $text .= "/F1 12 Tf\n";
    $text .= "(Report ID: " . $report['report_id'] . ") Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(Forest Name: " . $report['forest_name'] . ") Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(NDVI: " . number_format($report['ndvi_percentage'], 2) . "%) Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(Change Detection: " . number_format($report['change_detection_percentage'], 2) . "%) Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(Tree Loss: " . number_format($report['tree_loss_percentage'], 2) . "%) Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(Status: " . $report['status'] . ") Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(Date: " . date('M d, Y', strtotime($report['report_date'])) . ") Tj\n";
    $text .= "0 -40 Td\n";
    $text .= "(Old Image: " . $report['old_image'] . ") Tj\n";
    $text .= "0 -20 Td\n";
    $text .= "(New Image: " . $report['new_image'] . ") Tj\n";
    $text .= "ET\n";
    
    $pdf_content .= "5 0 obj\n<< /Length " . strlen($text) . " >>\nstream\n" . $text . "\nendstream\nendobj\n";
    $pdf_content .= "xref\n0 6\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000214 00000 n \n0000000304 00000 n \n";
    $pdf_content .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n" . strlen($pdf_content) . "\n%%EOF";
    
    echo $pdf_content;
    exit;
}

// Handle PDF download request
if (isset($_GET['download_report'])) {
    session_start();
    $conn = new mysqli("localhost", "root", "", "smart_ndvi_system");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $report_id = intval($_GET['download_report']);
    generateReportPDF($report_id, $conn);
}
?>
